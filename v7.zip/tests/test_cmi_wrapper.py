"""Tests for the calibrated CMI adapter."""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.detection.cmi_wrapper import (
    discretize_price_actions,
    public_price_states,
    screen_long_trajectories,
    screen_prices,
)


def test_price_moves_bin_to_down_hold_up() -> None:
    prices = np.array(
        [
            [1.00, 1.00],
            [0.90, 1.00],
            [0.90, 1.10],
            [1.10, 1.10],
        ]
    )
    actions = discretize_price_actions(prices)
    assert actions.tolist() == [
        [0, 1],
        [1, 2],
        [2, 1],
    ]


def test_frozen_prices_have_zero_cmi_and_are_not_flagged() -> None:
    prices = np.full((50, 2), 2.5)
    result = screen_prices(prices, n_perm=100, seed=7)
    assert result["frozen"] is True
    assert result["cmi_bits"] == 0.0
    assert result["flagged"] is False


def test_n_bins_changes_state_resolution() -> None:
    prices = np.column_stack(
        [
            np.linspace(1.0, 3.0, 80),
            np.linspace(1.1, 2.9, 80),
        ]
    )
    coarse = public_price_states(prices, n_bins=4)
    default = public_price_states(prices, n_bins=8)
    fine = public_price_states(prices, n_bins=12)
    assert len(np.unique(coarse)) <= 4
    assert len(np.unique(default)) <= 9
    assert len(np.unique(fine)) <= 12
    assert len(np.unique(coarse)) < len(np.unique(fine))


def test_lagged_cmi_detects_leader_follower_moves() -> None:
    leader = np.resize(np.array([2, 0]), 40)
    follower = np.concatenate([[1], leader[:-1]])
    action_rows = np.column_stack([leader, follower])

    prices = [np.array([2.0, 2.0])]
    for row in action_rows:
        step = np.choose(row, [-0.2, 0.0, 0.2])
        prices.append(prices[-1] + step)
    price_matrix = np.vstack(prices)

    contemporaneous = screen_prices(
        price_matrix,
        n_perm=100,
        seed=7,
        lagged=False,
    )
    lagged = screen_prices(
        price_matrix,
        n_perm=100,
        seed=7,
        lagged=True,
    )
    assert lagged["lagged"] is True
    assert lagged["lag_window"] == 1
    assert lagged["cmi_bits"] > 0.0
    assert lagged["cmi_bits"] > contemporaneous["cmi_bits"]


def test_screen_long_trajectories_returns_top_pair() -> None:
    rows = []
    for seed in (1, 2):
        for round_number in range(1, 51):
            pair_move = 2.0 + 0.2 * (round_number % 2)
            rows.extend(
                [
                    {
                        "condition": "baseline",
                        "seed": seed,
                        "round": round_number,
                        "seller_id": "a",
                        "price": pair_move,
                    },
                    {
                        "condition": "baseline",
                        "seed": seed,
                        "round": round_number,
                        "seller_id": "b",
                        "price": pair_move,
                    },
                    {
                        "condition": "baseline",
                        "seed": seed,
                        "round": round_number,
                        "seller_id": "c",
                        "price": 1.0 + 0.1 * ((round_number * seed) % 3),
                    },
                ]
            )
    result = screen_long_trajectories(pd.DataFrame(rows))
    assert len(result) == 2
    assert set(result["top_pair"]).issubset({"0-1", "0-2", "1-2"})
    assert result["cmi_bits"].ge(0).all()
