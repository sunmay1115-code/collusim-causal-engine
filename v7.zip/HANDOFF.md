# Collusim v5 Handoff

## Current State

V5 no longer uses RiskLab, Ollama, local model probes, local fingerprints, or
proxy fallback validation.

The dashboard has exactly two tabs:

1. **The Problem:** fixed empirical findings from E3, E4, and the shared
   history replacement study.
2. **The Solution:** Collusim's restriction frontier and objective ranking.

## Retained Components

- `src/detection/cmi_wrapper.py` is the detector and remains unchanged.
- `src/collusim/agents.py` remains unchanged.
- `src/collusim/environment.py` now supports the one-time history reset.
- `src/collusim/experiments.py` now includes `history_reset` in the RCT.
- `src/collusim/objectives.py` remains unchanged.
- The randomized Collusim RCT and evidence ranking remain unchanged.

## Removed Components

- RiskLab source and dependency installation.
- Ollama client and local probe pipeline.
- Local fingerprint dashboard.
- RiskLab validation results and fallback banner.
- Removed validation tests and entry points.

## Run

```bash
python -m pip install -r requirements.txt
python run_v5_pipeline.py
streamlit run app.py
```

`run_v5_pipeline.py` rebuilds scripted detector evidence, the Collusim RCT, and
the objective analysis. It never calls a model provider.

## Current Result

Noise injection at precision-loss strength `0.40` remains the selected
restriction:

- markup reduction: `74.0%`;
- CMI reduction: `85.4%`;
- welfare effect: `0.53%` improvement;
- efficiency ratio: `0.248`.

History reset is not the winner. With the requested `1.473` warm-up price, it
increases markup by `4.9%` and reduces CMI by `4.1%`, failing the
material-effect gate. Precision noise remains the least-cost restriction.

## Verification

```bash
python -m pytest tests -q
```

The retained CMI wrapper, Collusim experiment code, and objective ranking are
hash-checked after this cleanup.

## Starter Validation

`tools/run_starter_validation.py` executes the official Q1.1 duopoly and Q1.5
double-auction starters for one seed and short horizons. Because no hosted API
key is configured, it runs through a deterministic local OpenAI-compatible
mock and labels every result as `local_mock`.
