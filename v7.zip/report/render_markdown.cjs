const { marked } = require("marked");

let source = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  source += chunk;
});
process.stdin.on("end", () => {
  process.stdout.write(marked.parse(source, { gfm: true }));
});
