"""Render report.md to report.pdf using Markdown and headless Edge/Chrome."""

from __future__ import annotations

from io import BytesIO
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent
from pypdf import PdfReader, PdfWriter  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402


def find_browser() -> Path:
    candidates = [
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        Path(shutil.which("google-chrome") or ""),
        Path(shutil.which("chromium") or ""),
    ]
    for candidate in candidates:
        if str(candidate) and candidate.exists():
            return candidate
    raise FileNotFoundError("No Edge, Chrome, or Chromium executable found.")


def find_node() -> Path:
    candidates = [
        Path(shutil.which("node") or ""),
        Path(
            r"C:\Users\Man Ki Kuen\.cache\codex-runtimes"
            r"\codex-primary-runtime\dependencies\node\bin\node.exe"
        ),
    ]
    for candidate in candidates:
        if str(candidate) and candidate.exists():
            return candidate
    raise FileNotFoundError("Node.js is required to render Markdown.")


def render_markdown(source: str) -> str:
    node = find_node()
    node_modules = Path(
        os.environ.get(
            "NODE_PATH",
            r"C:\Users\Man Ki Kuen\.cache\codex-runtimes"
            r"\codex-primary-runtime\dependencies\node\node_modules",
        )
    )
    env = dict(os.environ)
    env["NODE_PATH"] = str(node_modules)
    result = subprocess.run(
        [str(node), str(HERE / "render_markdown.cjs")],
        input=source.encode("utf-8"),
        check=True,
        capture_output=True,
        env=env,
    )
    return result.stdout.decode("utf-8")


CSS = """
@page { size: A4; margin: 13mm 13mm 16mm 13mm; }
* { box-sizing: border-box; }
body {
  font-family: "Times New Roman", Times, serif;
  font-size: 9.3pt;
  line-height: 1.24;
  color: #111;
  margin: 0;
}
h1 {
  font-size: 15.5pt;
  text-align: center;
  line-height: 1.16;
  margin: 0 0 4pt;
}
h2 {
  font-size: 10.7pt;
  line-height: 1.2;
  margin: 7pt 0 2.5pt;
  page-break-after: avoid;
}
h3 {
  font-size: 9.5pt;
  line-height: 1.2;
  margin: 5pt 0 1.5pt;
  page-break-after: avoid;
}
p {
  margin: 0 0 3.5pt;
  text-align: justify;
  orphans: 3;
  widows: 3;
}
.authors {
  text-align: center;
  font-size: 8.7pt;
  line-height: 1.25;
  margin: 0 0 5pt;
}
.abstract {
  font-size: 8.6pt;
  background: #F5F7F6;
  border-left: 3pt solid #0F766E;
  padding: 5pt 7pt;
  margin: 2pt 0 5pt;
}
.abstract p { margin: 0; }
img {
  display: block;
  width: 100%;
  max-height: 65mm;
  object-fit: contain;
  margin: 2pt auto 1.5pt;
  page-break-inside: avoid;
}
em.caption {
  display: block;
  color: #444;
  font-size: 7.5pt;
  line-height: 1.26;
  text-align: left;
  margin: 0 0 4pt;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin: 2pt 0 4pt;
  font-size: 7.5pt;
  line-height: 1.16;
  page-break-inside: avoid;
}
th, td {
  border-top: 0.55pt solid #888;
  border-bottom: 0.55pt solid #888;
  padding: 1.6pt 2.7pt;
  text-align: center;
  vertical-align: top;
}
th { background: #F1F0EC; font-weight: bold; }
td:first-child, th:first-child { text-align: left; }
code { font-size: 8.6pt; }
pre {
  background: #F1F0EC;
  padding: 4pt 6pt;
  font-size: 8.2pt;
  line-height: 1.22;
  white-space: pre-wrap;
  page-break-inside: avoid;
}
ul, ol { margin: 0 0 4pt 14pt; padding: 0; }
li { margin-bottom: 1.5pt; }
a { color: #0F5E57; text-decoration: none; }
.page-break { page-break-before: always; }
.small { font-size: 8.6pt; color: #444; }
"""


def stamp_pdf(source: Path, destination: Path) -> None:
    reader = PdfReader(source)
    writer = PdfWriter()
    total = len(reader.pages)
    for index, page in enumerate(reader.pages, start=1):
        width = float(page.mediabox.width)
        height = float(page.mediabox.height)
        packet = BytesIO()
        footer = canvas.Canvas(packet, pagesize=(width, height))
        footer.setStrokeColorRGB(0.72, 0.75, 0.74)
        footer.setLineWidth(0.4)
        footer.line(45, 31, width - 45, 31)
        footer.setFillColorRGB(0.38, 0.42, 0.41)
        footer.setFont("Times-Roman", 7.8)
        footer.drawString(45, 20, "Collusim V6 | AI Collusion Research Sprint")
        footer.drawRightString(
            width - 45,
            20,
            f"Page {index} of {total}",
        )
        footer.save()
        packet.seek(0)
        page.merge_page(PdfReader(packet).pages[0])
        writer.add_page(page)
    writer.add_metadata(
        {
            "/Title": (
                "From Hidden Intent to Measurable Restrictions: "
                "A Calibrated CMI and Collusim Study of LLM Market Collusion"
            ),
            "/Author": "Man Ki Kuen (Sunny)",
            "/Subject": "AI collusion research sprint report",
        }
    )
    with destination.open("wb") as stream:
        writer.write(stream)


def main(src: Path = HERE / "report.md") -> None:
    md = src.read_text(encoding="utf-8")
    body = render_markdown(md)
    html = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        f"<style>{CSS}</style></head><body>{body}</body></html>"
    )
    html_path = src.with_suffix(".html")
    raw_pdf = src.with_name(f"{src.stem}.raw.pdf")
    final_pdf = src.with_suffix(".pdf")
    profile_dir = Path(tempfile.mkdtemp(prefix="collusim-report-"))
    html_path.write_text(html, encoding="utf-8")
    browser = find_browser()
    try:
        subprocess.run(
            [
                str(browser),
                "--headless=new",
                "--disable-gpu",
                "--no-first-run",
                "--no-pdf-header-footer",
                f"--user-data-dir={profile_dir}",
                f"--print-to-pdf={raw_pdf}",
                html_path.as_uri(),
            ],
            check=True,
            capture_output=True,
        )
        stamp_pdf(raw_pdf, final_pdf)
    finally:
        html_path.unlink(missing_ok=True)
        raw_pdf.unlink(missing_ok=True)
        shutil.rmtree(profile_dir, ignore_errors=True)
    print(f"wrote {final_pdf}")


if __name__ == "__main__":
    source = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE / "report.md"
    main(source)
