"""Generate report figures from saved V7 result artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = Path(__file__).resolve().parent / "figures"

INK = "#17211F"
MUTED = "#5F6B68"
GRID = "#DCE4E1"
PAPER = "#FFFFFF"
TEAL = "#0F766E"
ORANGE = "#D97706"
PURPLE = "#7C3AED"
RED = "#C2410C"
BLUE = "#2563EB"
GREY = "#64748B"


def _style() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8.5,
            "axes.titlesize": 10,
            "axes.labelsize": 8.5,
            "axes.edgecolor": GREY,
            "axes.labelcolor": INK,
            "xtick.color": MUTED,
            "ytick.color": MUTED,
            "text.color": INK,
            "figure.facecolor": PAPER,
            "axes.facecolor": PAPER,
            "savefig.facecolor": PAPER,
        }
    )


def evidence_figure() -> None:
    figure, (left, middle, right) = plt.subplots(
        1,
        3,
        figsize=(9.5, 3.1),
    )
    left.bar(
        ["Chat", "No chat"],
        [87, 78],
        color=[TEAL, GREY],
        width=0.58,
    )
    left.set_ylim(0, 100)
    left.set_ylabel("Seller-round hold rate (%)")
    left.set_title("Assanali E3")
    for index, value in enumerate([87, 78]):
        left.text(index, value + 2, f"{value}%", ha="center", va="bottom")

    labels = ["Allied\nchannel", "Allied\ntacit", "Other pairs\nsame games"]
    values = [42, 43, 45]
    middle.bar(
        labels,
        values,
        color=[RED, ORANGE, GREY],
        width=0.58,
    )
    middle.set_ylim(0, 60)
    middle.set_ylabel("Same-region rate (%)")
    middle.set_title("Assanali E4")
    for index, value in enumerate(values):
        middle.text(index, value + 1.2, f"{value}%", ha="center", va="bottom")
    middle.text(
        0.5,
        0.84,
        "Wilcoxon p = 0.53 and 0.55",
        transform=middle.transAxes,
        ha="center",
        color=MUTED,
    )

    right.bar(
        ["Newcomer\nsees history", "Fresh\npair"],
        [0.80, 0.32],
        color=[BLUE, GREY],
        width=0.58,
    )
    right.set_ylim(0, 1.0)
    right.set_ylabel("G50 profit gain")
    right.set_title("Abilmansur")
    for index, value in enumerate([0.80, 0.32]):
        right.text(index, value + 0.02, f"{value:.2f}", ha="center", va="bottom")
    right.text(
        0.5,
        0.84,
        "p = 0.001",
        transform=right.transAxes,
        ha="center",
        color=MUTED,
    )
    for axis in (left, middle, right):
        axis.grid(axis="y", color=GRID, linewidth=0.6, alpha=0.8)
        axis.spines[["top", "right"]].set_visible(False)
    figure.tight_layout(w_pad=2.0)
    figure.savefig(FIGURES / "fig_empirical.png", dpi=220, bbox_inches="tight")
    plt.close(figure)


def starter_q11_figure() -> None:
    baseline = pd.read_csv(RESULTS / "starter_q11_baseline.csv")
    ablation = pd.read_csv(RESULTS / "starter_q11_ablation.csv")
    benchmark = float(baseline["competitive_benchmark"].iloc[0])

    figure, axis = plt.subplots(figsize=(8.8, 3.1))
    axis.plot(
        baseline["round"],
        baseline["mean_price"],
        color=TEAL,
        linewidth=1.9,
        marker="o",
        markersize=3,
        label="100 visible rounds",
    )
    axis.plot(
        ablation["round"],
        ablation["mean_price"],
        color=RED,
        linewidth=1.9,
        marker="o",
        markersize=3,
        label="0 visible rounds",
    )
    axis.axhline(
        benchmark,
        color=GREY,
        linewidth=1.0,
        linestyle="--",
        label=f"Competitive benchmark = {benchmark:.3f}",
    )
    axis.set_xlabel("Round")
    axis.set_ylabel("Mean price")
    axis.set_title("Official Q1.1 starter replication: visible history")
    axis.grid(color=GRID, linewidth=0.6, alpha=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    axis.legend(frameon=False)
    figure.tight_layout()
    figure.savefig(
        FIGURES / "fig_starter_q11.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(figure)


def architecture_figure() -> None:
    figure, axis = plt.subplots(figsize=(9.2, 3.3))
    axis.set_xlim(0, 10)
    axis.set_ylim(0, 4)
    axis.axis("off")

    def box(
        x: float,
        y: float,
        width: float,
        height: float,
        title: str,
        body: str,
        color: str,
    ) -> None:
        patch = FancyBboxPatch(
            (x, y),
            width,
            height,
            boxstyle="round,pad=0.06,rounding_size=0.10",
            linewidth=1.0,
            edgecolor=color,
            facecolor="#FAFCFB",
        )
        axis.add_patch(patch)
        axis.text(
            x + width / 2,
            y + height - 0.32,
            title,
            ha="center",
            va="top",
            fontsize=9,
            fontweight="bold",
            color=color,
        )
        axis.text(
            x + width / 2,
            y + height / 2 - 0.18,
            body,
            ha="center",
            va="center",
            fontsize=7.6,
            color=INK,
            linespacing=1.35,
        )

    def arrow(start: tuple[float, float], end: tuple[float, float]) -> None:
        axis.add_patch(
            FancyArrowPatch(
                start,
                end,
                arrowstyle="-|>",
                mutation_scale=10,
                linewidth=1.2,
                color=GREY,
            )
        )

    box(
        0.15,
        2.45,
        2.25,
        1.15,
        "Empirical evidence",
        "Assanali E3/E4\nAbilmansur history",
        RED,
    )
    box(
        0.15,
        0.55,
        2.25,
        1.15,
        "Saved calibration",
        "OLS proxy parameters\nand residual draws",
        GREY,
    )
    box(
        3.0,
        0.55,
        2.25,
        1.15,
        "Collusim RCT",
        "Precision, delay,\nvisibility, history reset",
        TEAL,
    )
    box(
        3.0,
        2.45,
        2.25,
        1.15,
        "CMI detector",
        "Discrete actions\npublic-price state",
        PURPLE,
    )
    box(
        5.85,
        1.55,
        1.75,
        1.15,
        "Evidence gates",
        "Controls, CIs,\nfreeze checks",
        ORANGE,
    )
    box(
        8.10,
        2.45,
        1.75,
        1.15,
        "Problem tab",
        "Assanali evidence\nAbilmansur history",
        RED,
    )
    box(
        8.10,
        0.55,
        1.75,
        1.15,
        "Solution tab",
        "74% noise\ninjection win",
        TEAL,
    )
    axis.plot(
        [1.30, 1.30, 8.92],
        [3.60, 3.82, 3.82],
        color=GREY,
        linewidth=1.1,
        linestyle=(0, (3, 3)),
    )
    arrow((8.92, 3.82), (8.92, 3.60))
    arrow((2.40, 1.12), (3.00, 1.12))
    arrow((5.25, 1.12), (5.85, 1.70))
    arrow((2.40, 1.30), (3.00, 2.90))
    arrow((5.25, 3.02), (5.85, 2.20))
    arrow((7.60, 2.15), (8.10, 1.12))
    figure.savefig(
        FIGURES / "fig_architecture.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(figure)


def frontier_figure() -> None:
    ranking = pd.read_csv(RESULTS / "objective_1_5_restriction_ranking.csv")
    summary = json.loads(
        (RESULTS / "v5_objective_summary.json").read_text(encoding="ascii")
    )
    winner = summary["objective_1_5"]["winner"]
    hard_ban = summary["objective_1_5"]["hard_ban"]

    figure, axis = plt.subplots(figsize=(8.7, 3.65))
    colors = {
        "precision": TEAL,
        "delay": ORANGE,
        "visibility": PURPLE,
        "history_reset": BLUE,
    }
    labels = {
        "precision": "Noise injection",
        "delay": "Price delay",
        "visibility": "Visibility loss",
        "history_reset": "History reset",
    }
    for lever, part in ranking.groupby("lever"):
        part = part.sort_values("strength")
        axis.plot(
            part["welfare_change_pct"] * 100,
            part["markup_reduction_pct"] * 100,
            marker="o",
            markersize=4.5,
            linewidth=1.8,
            color=colors[lever],
            label=labels[lever],
        )
    axis.scatter(
        [winner["welfare_change_pct"] * 100],
        [winner["markup_reduction_pct"] * 100],
        marker="*",
        s=230,
        color="#F59E0B",
        edgecolor="#78350F",
        linewidth=0.9,
        zorder=5,
        label="Selected restriction",
    )
    axis.scatter(
        [hard_ban["welfare_change_pct"] * 100],
        [hard_ban["markup_reduction_pct"] * 100],
        marker="X",
        s=90,
        color=GREY,
        edgecolor=PAPER,
        linewidth=0.8,
        zorder=5,
        label="Hard ban",
    )
    axis.axvline(0, color=GREY, linewidth=0.8)
    axis.axhline(0, color=GREY, linewidth=0.8)
    axis.set_xlabel("Welfare change (%) [negative = improvement]")
    axis.set_ylabel("Markup reduction (%)")
    axis.set_title("Restriction trade-off under Collusim")
    axis.grid(color=GRID, linewidth=0.6, alpha=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    axis.legend(
        frameon=False,
        ncol=5,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.24),
        fontsize=7.8,
    )
    figure.tight_layout()
    figure.savefig(FIGURES / "fig_frontier.png", dpi=220, bbox_inches="tight")
    plt.close(figure)


def pareto_frontier_figure() -> None:
    raw = pd.read_csv(RESULTS / "collusim_rct_raw.csv")
    colors = {
        "precision": TEAL,
        "delay": ORANGE,
        "visibility": PURPLE,
        "hard_ban": GREY,
    }
    labels = {
        "precision": "Noise injection",
        "delay": "Delay",
        "visibility": "Visibility loss",
        "hard_ban": "Hard ban",
    }
    menu = (
        raw.loc[raw["lever"].isin(colors)]
        .groupby(["lever", "strength"], as_index=False)
        .agg(
            consumer_welfare=("consumer_welfare", "mean"),
            producer_profit=("producer_profit", "mean"),
        )
        .reset_index(drop=True)
    )
    dominated = np.zeros(len(menu), dtype=bool)
    for index, point in menu.iterrows():
        dominated[index] = bool(
            (
                (menu["consumer_welfare"] >= point["consumer_welfare"])
                & (menu["producer_profit"] >= point["producer_profit"])
                & (
                    (menu["consumer_welfare"] > point["consumer_welfare"])
                    | (menu["producer_profit"] > point["producer_profit"])
                )
            ).any()
        )
    frontier = menu.loc[~dominated].sort_values("consumer_welfare")

    figure, axis = plt.subplots(figsize=(9.0, 3.5))
    axis.plot(
        frontier["consumer_welfare"],
        frontier["producer_profit"],
        color=INK,
        linewidth=1.8,
        linestyle="--",
        marker="o",
        markersize=4,
        label="Pareto frontier",
        zorder=2,
    )
    for lever, part in menu.groupby("lever"):
        axis.scatter(
            part["consumer_welfare"],
            part["producer_profit"],
            s=42 if lever != "hard_ban" else 60,
            marker="o" if lever != "hard_ban" else "X",
            color=colors[lever],
            edgecolor=PAPER,
            linewidth=0.6,
            label=labels[lever],
            zorder=3,
        )
    selected = menu.loc[
        (menu["lever"] == "precision")
        & np.isclose(menu["strength"], 0.40)
    ].iloc[0]
    axis.scatter(
        [selected["consumer_welfare"]],
        [selected["producer_profit"]],
        marker="*",
        s=210,
        color="#F59E0B",
        edgecolor="#78350F",
        linewidth=0.8,
        label="Precision Loss 0.40",
        zorder=5,
    )
    axis.annotate(
        "Policy Menu: Regulators can choose their preferred trade-off.\n"
        "Precision Loss dominates the frontier.",
        xy=(0.03, 0.06),
        xycoords="axes fraction",
        ha="left",
        va="bottom",
        fontsize=7.4,
        color=INK,
        bbox={
            "boxstyle": "round,pad=0.35",
            "facecolor": "#F8FAF9",
            "edgecolor": "#CBD5D1",
        },
        zorder=6,
    )
    axis.set_xlabel("Consumer surplus (mean)")
    axis.set_ylabel("Producer profit (mean)")
    axis.set_title("Multi-objective policy menu")
    axis.grid(color=GRID, linewidth=0.6, alpha=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    axis.legend(
        frameon=False,
        ncol=3,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.18),
        fontsize=7.2,
    )
    figure.tight_layout()
    figure.savefig(
        FIGURES / "fig_pareto_frontier.png",
        dpi=220,
        bbox_inches="tight",
    )
    plt.close(figure)


def ablation_figure() -> None:
    ranking = pd.read_csv(RESULTS / "objective_1_5_restriction_ranking.csv")
    summary = json.loads(
        (RESULTS / "v5_objective_summary.json").read_text(encoding="ascii")
    )
    winner = summary["objective_1_5"]["winner"]
    colors = {
        "precision": TEAL,
        "delay": ORANGE,
        "visibility": PURPLE,
        "history_reset": BLUE,
    }
    labels = {
        "precision": "Noise injection",
        "delay": "Price delay",
        "visibility": "Visibility loss",
        "history_reset": "History reset",
    }
    figure, axis = plt.subplots(figsize=(8.7, 3.55))
    for lever, part in ranking.groupby("lever"):
        axis.scatter(
            part["cmi_reduction_pct"] * 100,
            part["markup_reduction_pct"] * 100,
            s=25 + part["efficiency_ratio"].abs() * 420,
            color=colors[lever],
            alpha=0.82,
            edgecolor=PAPER,
            linewidth=0.6,
            label=labels[lever],
        )
    axis.scatter(
        [winner["cmi_reduction_pct"] * 100],
        [winner["markup_reduction_pct"] * 100],
        marker="*",
        s=260,
        color="#F59E0B",
        edgecolor="#78350F",
        linewidth=0.9,
        zorder=5,
    )
    axis.annotate(
        "Noise injection, strength 0.40\n74.0% markup / 85.4% CMI",
        (
            winner["cmi_reduction_pct"] * 100,
            winner["markup_reduction_pct"] * 100,
        ),
        xytext=(51, 33),
        textcoords="data",
        fontsize=7.7,
        color=INK,
        arrowprops={"arrowstyle": "-", "color": GREY, "linewidth": 0.8},
    )
    axis.set_xlim(0, 102)
    axis.set_ylim(-8, 82)
    axis.set_xlabel("CMI reduction (%)")
    axis.set_ylabel("Markup reduction (%)")
    axis.set_title("Every restriction measured by price and dependence")
    axis.grid(color=GRID, linewidth=0.6, alpha=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    axis.legend(frameon=False, loc="lower left")
    figure.tight_layout()
    figure.savefig(FIGURES / "fig_ablation.png", dpi=220, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    _style()
    FIGURES.mkdir(parents=True, exist_ok=True)
    evidence_figure()
    starter_q11_figure()
    architecture_figure()
    frontier_figure()
    pareto_frontier_figure()
    ablation_figure()
    print(f"Wrote report figures to {FIGURES}")


if __name__ == "__main__":
    main()
