# External E3 evidence

`e3_auction_runs/` contains the 75 auction log directories used by Assanali
Alibatyrkhan's E3 analysis. Each directory retains the source
`experiment_metadata.json`, `auction_results.md`, and optional
`collusion_metrics.json`.

The two JSON files beside this note are the corresponding teammate outputs:

- `assanali_e3_auction_runs.json`
- `assanali_e3_auction_auroc.json`

V6 reads the raw run directories through
`src/detection/cmi_wrapper.py::screen_prices` and checks the adapter against
`src/external/infocollusion/detect.py::screen`.
