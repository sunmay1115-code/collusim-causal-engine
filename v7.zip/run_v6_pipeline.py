"""Rebuild the V6 deterministic pipeline and all robustness outputs."""

from __future__ import annotations

import json

from src.collusim.experiments import run_rct
from src.collusim.objectives import write_objective_outputs
from src.core_sim import build_episode_dataset
from src.detector import train_and_evaluate
from src.v6_robustness import run_all


def main() -> int:
    episodes = build_episode_dataset()
    detector = train_and_evaluate(episodes)
    print(
        f"Detector AUC={detector['auc']:.3f}; "
        f"scope={detector['validation_scope']}"
    )
    frontier = run_rct()
    objective = write_objective_outputs()
    robustness = run_all()
    winner = objective["objective_1_5"]["winner"]
    if winner is None:
        print("Objective 1.5: no restriction passed all evidence gates.")
    else:
        print(
            "Objective 1.5 winner: "
            f"{winner['lever']} at {winner['strength']:.2f}; "
            f"markup reduction={winner['markup_reduction_pct']:.1%}, "
            f"CMI reduction={winner['cmi_reduction_pct']:.1%}"
        )
    e3 = robustness["e3_consistency"]
    print(
        f"E3 consistency: flag rate={e3['flag_rate']:.1%}, "
        f"mean z={e3['mean_z']:.3f}"
    )
    print(json.dumps(robustness, indent=2, allow_nan=False))
    print("V6 pipeline complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
