"""Adapter from continuous Collusim prices to the teammate's calibrated CMI screen."""

from __future__ import annotations

import math
import sys
from itertools import combinations
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
EXTERNAL_DIR = ROOT / "src" / "external"
if str(EXTERNAL_DIR) not in sys.path:
    sys.path.insert(0, str(EXTERNAL_DIR))

from infocollusion.detect import screen  # noqa: E402
from infocollusion.estimators import permutation_test  # noqa: E402


DEFAULT_STATE_BINS = (1.1, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75)
DEFAULT_N_BINS = 8


def discretize_price_actions(
    prices: np.ndarray,
    hold_threshold: float = 0.01,
) -> np.ndarray:
    """Map own-price changes to Down=0, Hold=1, Up=2."""

    values = np.asarray(prices, dtype=float)
    if values.ndim != 2:
        raise ValueError("prices must have shape (rounds, agents)")
    if len(values) < 2:
        raise ValueError("at least two rounds are required")
    changes = np.diff(values, axis=0)
    actions = np.ones_like(changes, dtype=np.int64)
    actions[changes < -hold_threshold] = 0
    actions[changes > hold_threshold] = 2
    return actions


def state_bin_edges(
    prices: np.ndarray,
    n_bins: int = DEFAULT_N_BINS,
) -> tuple[float, ...]:
    """Resolve price-state edges while preserving the V5 default at 8 bins."""

    values = np.asarray(prices, dtype=float)
    if values.ndim != 2:
        raise ValueError("prices must have shape (rounds, agents)")
    if n_bins < 2:
        raise ValueError("n_bins must be at least 2")
    if n_bins == DEFAULT_N_BINS:
        return DEFAULT_STATE_BINS
    previous_mean = values[:-1].mean(axis=1)
    quantiles = np.linspace(0.0, 1.0, n_bins + 1)[1:-1]
    edges = np.unique(np.quantile(previous_mean, quantiles))
    return tuple(float(edge) for edge in edges)


def public_price_states(
    prices: np.ndarray,
    bins: tuple[float, ...] | None = None,
    n_bins: int = DEFAULT_N_BINS,
) -> np.ndarray:
    """Summarize the previous public price level, excluding the current action."""

    values = np.asarray(prices, dtype=float)
    edges = state_bin_edges(values, n_bins=n_bins) if bins is None else bins
    previous_mean = values[:-1].mean(axis=1)
    return np.digitize(previous_mean, edges).astype(np.int64)


def _action_entropy(actions: np.ndarray) -> float:
    counts = np.bincount(actions.ravel(), minlength=3).astype(float)
    probabilities = counts / max(counts.sum(), 1.0)
    return float(
        -sum(
            probability * math.log2(probability)
            for probability in probabilities
            if probability > 0
        )
    )


def _screen_lagged_actions(
    actions: np.ndarray,
    states: np.ndarray,
    *,
    n_perm: int,
    level: float,
    seed: int,
) -> list[dict[str, Any]]:
    """Test symmetric cross-lagged dependence for every unordered agent pair."""

    if len(actions) < 2:
        raise ValueError("lagged CMI requires at least three price rounds")
    n_agents = actions.shape[1]
    pairs = list(combinations(range(n_agents), 2))
    directed_tests = max(1, 2 * len(pairs))
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    current_actions = actions[1:]
    lagged_actions = actions[:-1]
    lagged_states = states[1:]
    for first, second in pairs:
        forward = permutation_test(
            current_actions[:, first],
            lagged_actions[:, second],
            lagged_states,
            n_perm=n_perm,
            miller_madow=True,
            rng=rng,
        )
        reverse = permutation_test(
            current_actions[:, second],
            lagged_actions[:, first],
            lagged_states,
            n_perm=n_perm,
            miller_madow=True,
            rng=rng,
        )
        adjusted_p = min(
            1.0,
            min(forward.p, reverse.p) * directed_tests,
        )
        rows.append(
            {
                "pair": (first, second),
                "cmi_bits": float(
                    (forward.gamma + reverse.gamma) / (2.0 * math.log(2.0))
                ),
                "net_influence_bits": float(
                    min(forward.gamma, reverse.gamma) / math.log(2.0)
                ),
                "z": float((forward.z + reverse.z) / 2.0),
                "p": float(adjusted_p),
                "flagged": bool(
                    adjusted_p < level
                    and forward.gamma > 0.0
                    and reverse.gamma > 0.0
                ),
            }
        )
    return sorted(rows, key=lambda row: -row["z"])


def screen_prices(
    prices: np.ndarray,
    *,
    hold_threshold: float = 0.01,
    n_perm: int = 200,
    level: float = 0.05,
    seed: int = 0,
    n_bins: int = DEFAULT_N_BINS,
    state_bins: tuple[float, ...] | None = None,
    states: np.ndarray | None = None,
    lagged: bool = False,
) -> dict[str, Any]:
    """Run the calibrated screen on a continuous ``(rounds, agents)`` price log."""

    values = np.asarray(prices, dtype=float)
    actions = discretize_price_actions(values, hold_threshold=hold_threshold)
    if states is None:
        if state_bins is None:
            state_bins = state_bin_edges(values, n_bins=n_bins)
            state_mode = (
                "v5_default_fixed"
                if n_bins == DEFAULT_N_BINS
                else "quantile"
            )
        else:
            state_mode = "explicit_bins"
        state_values = public_price_states(
            values,
            bins=state_bins,
            n_bins=n_bins,
        )
    else:
        state_values = np.asarray(states)
        if state_values.ndim != 1 or len(state_values) != len(actions):
            raise ValueError(
                "states must be a one-dimensional array aligned to actions"
            )
        state_mode = "explicit_states"
    rows = (
        _screen_lagged_actions(
            actions,
            state_values,
            n_perm=n_perm,
            level=level,
            seed=seed,
        )
        if lagged
        else screen(
            actions,
            state_values,
            n_perm=n_perm,
            level=level,
            seed=seed,
        )
    )
    if not rows:
        raise ValueError("CMI screen returned no agent pairs")
    top = dict(rows[0])
    pair = tuple(int(index) for index in top["pair"])
    return {
        "top_pair": f"{pair[0]}-{pair[1]}",
        "cmi_bits": float(top["cmi_bits"]),
        "net_influence_bits": float(top["net_influence_bits"]),
        "z": float(top["z"]),
        "p_value": float(top["p"]),
        "flagged": bool(top["flagged"]),
        "action_entropy_bits": _action_entropy(actions),
        "frozen": bool((actions == actions.flat[0]).all()),
        "n_bins": int(n_bins),
        "state_bin_mode": state_mode,
        "state_bin_edges": list(state_bins)
        if states is None and state_bins is not None
        else [],
        "lagged": bool(lagged),
        "lag_window": 1 if lagged else 0,
    }


def screen_long_trajectories(
    frame: pd.DataFrame,
    *,
    group_columns: tuple[str, ...] = ("condition", "seed"),
    entity_column: str = "seller_id",
    round_column: str = "round",
    price_column: str = "price",
    hold_threshold: float = 0.01,
    n_bins: int = DEFAULT_N_BINS,
    lagged: bool = False,
) -> pd.DataFrame:
    """Screen each multi-agent trajectory stored in long form."""

    required = {
        *group_columns,
        entity_column,
        round_column,
        price_column,
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Trajectory table missing columns: {sorted(missing)}")
    rows: list[dict[str, Any]] = []
    for group_key, part in frame.groupby(list(group_columns), sort=True):
        if not isinstance(group_key, tuple):
            group_key = (group_key,)
        matrix = (
            part.pivot(
                index=round_column,
                columns=entity_column,
                values=price_column,
            )
            .sort_index()
            .to_numpy(dtype=float)
        )
        result = screen_prices(
            matrix,
            hold_threshold=hold_threshold,
            n_bins=n_bins,
            lagged=lagged,
        )
        rows.append(
            {
                **dict(zip(group_columns, group_key)),
                **result,
                "agents": int(matrix.shape[1]),
                "rounds": int(matrix.shape[0]),
            }
        )
    return pd.DataFrame(rows)
