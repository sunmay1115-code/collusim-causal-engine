"""V6 robustness checks for the calibrated CMI and welfare rankings."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from config import CI_LEVEL, COLLUSIM_SEEDS, RESULTS_DIR, ROOT, SEED
from deferred.llm_track.common import bootstrap_ci
from src.collusim.environment import run_episode
from src.collusim.objectives import write_welfare_sensitivity_outputs
from src.detection.cmi_wrapper import (
    discretize_price_actions,
    screen_prices,
    state_bin_edges,
)
from infocollusion.detect import screen  # noqa: E402


E3_ROOT = ROOT / "data" / "external" / "e3_auction_runs"
E3_HOLD_THRESHOLD = 0.25
E3_N_PERM = 500
BIN_VALUES = (4, 8, 12)
NOISE_STRENGTH = 0.40
_ROUND_JSON = re.compile(r"````json\n(.*?)\n````", re.S)


def _condition_from_tag(tag: str) -> str:
    return re.sub(r"-\d+$", "", tag)


def load_e3_runs(root: Path = E3_ROOT) -> list[dict[str, Any]]:
    """Parse Assanali's 75 E3 auction runs into calibrated price panels."""

    runs: list[dict[str, Any]] = []
    for run_dir in sorted(path for path in root.iterdir() if path.is_dir()):
        metadata_path = run_dir / "experiment_metadata.json"
        results_path = run_dir / "auction_results.md"
        if not metadata_path.exists() or not results_path.exists():
            continue
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        rounds = [
            json.loads(block)
            for block in _ROUND_JSON.findall(
                results_path.read_text(encoding="utf-8")
            )
        ]
        sellers = list(metadata["seller_ids"])
        asks = np.full((len(rounds), len(sellers)), np.nan, dtype=float)
        trades = np.zeros(len(rounds), dtype=int)
        for round_index, round_payload in enumerate(rounds):
            for seller_index, seller in enumerate(sellers):
                value = round_payload["seller_asks"].get(seller)
                if value is not None:
                    asks[round_index, seller_index] = float(value)
            trades[round_index] = len(round_payload["trades"])
        for seller_index in range(asks.shape[1]):
            for round_index in range(asks.shape[0]):
                if np.isnan(asks[round_index, seller_index]):
                    asks[round_index, seller_index] = (
                        asks[round_index - 1, seller_index]
                        if round_index > 0
                        else float(np.nanmean(asks[0]))
                    )
        if not np.isfinite(asks).all():
            raise ValueError(f"E3 run contains unresolved missing asks: {run_dir}")
        config = metadata["auction_config"]
        runs.append(
            {
                "run_id": run_dir.name,
                "condition": _condition_from_tag(str(config["tag"])),
                "comms": bool(config["seller_comms_enabled"]),
                "asks": asks,
                "trades": trades,
            }
        )
    if len(runs) != 75:
        raise ValueError(f"Expected 75 E3 auction runs, found {len(runs)}")
    return runs


def run_e3_consistency() -> pd.DataFrame:
    """Screen the E3 logs through the V6 CMI adapter."""

    rows: list[dict[str, Any]] = []
    for index, run in enumerate(load_e3_runs()):
        asks = np.asarray(run["asks"], dtype=float)
        trades = np.asarray(run["trades"], dtype=int)
        states = (trades[:-1] > 0).astype(int)
        seed = SEED + 900 + index
        result = screen_prices(
            asks,
            hold_threshold=E3_HOLD_THRESHOLD,
            n_perm=E3_N_PERM,
            seed=seed,
            states=states,
        )
        actions = discretize_price_actions(
            asks,
            hold_threshold=E3_HOLD_THRESHOLD,
        )
        teammate_top = dict(
            screen(
                actions,
                states,
                n_perm=E3_N_PERM,
                seed=seed,
            )[0]
        )
        cmi_difference = abs(
            float(result["cmi_bits"]) - float(teammate_top["cmi_bits"])
        )
        z_difference = abs(float(result["z"]) - float(teammate_top["z"]))
        rows.append(
            {
                "run_id": run["run_id"],
                "condition": run["condition"],
                "comms": run["comms"],
                "rounds": int(asks.shape[0]),
                "sellers": int(asks.shape[1]),
                "top_pair": result["top_pair"],
                "cmi_bits": result["cmi_bits"],
                "z": result["z"],
                "p_value": result["p_value"],
                "flagged": result["flagged"],
                "action_entropy_bits": result["action_entropy_bits"],
                "frozen": result["frozen"],
                "teammate_cmi_difference_bits": cmi_difference,
                "teammate_z_difference": z_difference,
            }
        )
    runs = pd.DataFrame(rows)
    with_comms = runs.loc[runs["comms"]]
    without_comms = runs.loc[~runs["comms"]]
    summary = pd.DataFrame(
        [
            {
                "dataset": "Assanali E3 double-auction logs",
                "source_runs": len(runs),
                "n_flagged": int(runs["flagged"].sum()),
                "flag_rate": float(runs["flagged"].mean()),
                "mean_z": float(runs["z"].mean()),
                "median_z": float(runs["z"].median()),
                "mean_cmi_bits": float(runs["cmi_bits"].mean()),
                "mean_action_entropy_bits": float(
                    runs["action_entropy_bits"].mean()
                ),
                "chatting_sellers_runs": len(with_comms),
                "chatting_sellers_flag_rate": float(with_comms["flagged"].mean()),
                "chatting_sellers_mean_z": float(with_comms["z"].mean()),
                "no_chat_runs": len(without_comms),
                "no_chat_flag_rate": float(without_comms["flagged"].mean()),
                "no_chat_mean_z": float(without_comms["z"].mean()),
                "hold_threshold": E3_HOLD_THRESHOLD,
                "conditioning_state": "previous round had at least one trade",
                "n_perm": E3_N_PERM,
                "adapter": "src/detection/cmi_wrapper.py::screen_prices",
                "teammate_math": "src/external/infocollusion/detect.py::screen",
                "adapter_math_match_rate": float(
                    np.isclose(
                        runs["teammate_cmi_difference_bits"],
                        0.0,
                    ).mean()
                ),
                "max_abs_cmi_difference_bits": float(
                    runs["teammate_cmi_difference_bits"].max()
                ),
                "max_abs_z_difference": float(
                    runs["teammate_z_difference"].max()
                ),
            }
        ]
    )
    summary.to_csv(RESULTS_DIR / "e3_consistency.csv", index=False)
    return summary


def _run_price_condition(
    condition: str,
    *,
    precision: float = 0.0,
    agent_type: str = "llm",
) -> pd.DataFrame:
    rows = []
    for index in range(COLLUSIM_SEEDS):
        seed = SEED + index
        result = run_episode(
            seed=seed,
            precision=precision,
            agent_type=agent_type,
        )
        rows.append(
            {
                "condition": condition,
                "seed": seed,
                "prices": result["prices"],
                "mean_markup": float(result["mean_markup"]),
                "total_welfare": float(result["total_welfare"]),
            }
        )
    return pd.DataFrame(rows)


def _gap_ci(values: np.ndarray, seed: int) -> tuple[float, float, float]:
    point, low, high = bootstrap_ci(
        np.asarray(values, dtype=float),
        n_boot=1000,
        ci=CI_LEVEL,
        seed=seed,
    )
    return float(point), float(low), float(high)


def run_bin_sensitivity() -> pd.DataFrame:
    """Compare noise 0.40 with the hard ban under 4, 8, and 12 bins."""

    baseline = _run_price_condition("baseline")
    noise = _run_price_condition(
        "noise_0.40",
        precision=NOISE_STRENGTH,
    )
    hard_ban = _run_price_condition("hard_ban", agent_type="human")
    baseline_prices = np.concatenate(baseline["prices"].tolist(), axis=0)
    output_rows: list[dict[str, Any]] = []
    for bin_index, n_bins in enumerate(BIN_VALUES):
        edges = state_bin_edges(baseline_prices, n_bins=n_bins)
        screened: dict[str, list[dict[str, Any]]] = {}
        for condition, frame in (
            ("baseline", baseline),
            ("noise_0.40", noise),
            ("hard_ban", hard_ban),
        ):
            condition_rows = []
            for row in frame.itertuples():
                cmi = screen_prices(
                    row.prices,
                    hold_threshold=0.01,
                    n_perm=100,
                    seed=int(row.seed) + 1200 + bin_index,
                    n_bins=n_bins,
                    state_bins=edges,
                )
                condition_rows.append(
                    {
                        "seed": int(row.seed),
                        "mean_markup": float(row.mean_markup),
                        "total_welfare": float(row.total_welfare),
                        "cmi_bits": float(cmi["cmi_bits"]),
                        "cmi_z": float(cmi["z"]),
                        "cmi_flagged": bool(cmi["flagged"]),
                        "cmi_frozen": bool(cmi["frozen"]),
                        "cmi_action_entropy": float(
                            cmi["action_entropy_bits"]
                        ),
                    }
                )
            screened[condition] = condition_rows
        baseline_rows = pd.DataFrame(screened["baseline"])
        noise_rows = pd.DataFrame(screened["noise_0.40"])
        ban_rows = pd.DataFrame(screened["hard_ban"])
        noise_paired = baseline_rows.merge(
            noise_rows,
            on="seed",
            suffixes=("_baseline", "_condition"),
        )
        ban_paired = baseline_rows.merge(
            ban_rows,
            on="seed",
            suffixes=("_baseline", "_condition"),
        )
        noise_markup_gap = (
            noise_paired["mean_markup_baseline"]
            - noise_paired["mean_markup_condition"]
        ).to_numpy()
        ban_markup_gap = (
            ban_paired["mean_markup_baseline"]
            - ban_paired["mean_markup_condition"]
        ).to_numpy()
        noise_cmi_gap = (
            noise_paired["cmi_bits_baseline"]
            - noise_paired["cmi_bits_condition"]
        ).to_numpy()
        ban_cmi_gap = (
            ban_paired["cmi_bits_baseline"]
            - ban_paired["cmi_bits_condition"]
        ).to_numpy()
        baseline_markup = float(baseline_rows["mean_markup"].mean())
        baseline_cmi = float(baseline_rows["cmi_bits"].mean())
        noise_markup, noise_markup_low, noise_markup_high = _gap_ci(
            noise_markup_gap,
            SEED + 1300 + bin_index,
        )
        ban_markup, ban_markup_low, ban_markup_high = _gap_ci(
            ban_markup_gap,
            SEED + 1310 + bin_index,
        )
        noise_cmi, noise_cmi_low, noise_cmi_high = _gap_ci(
            noise_cmi_gap,
            SEED + 1320 + bin_index,
        )
        ban_cmi, ban_cmi_low, ban_cmi_high = _gap_ci(
            ban_cmi_gap,
            SEED + 1330 + bin_index,
        )
        noise_reduction = noise_markup / max(abs(baseline_markup), 1e-9)
        ban_reduction = ban_markup / max(abs(baseline_markup), 1e-9)
        noise_cmi_reduction = noise_cmi / max(abs(baseline_cmi), 1e-9)
        ban_cmi_reduction = ban_cmi / max(abs(baseline_cmi), 1e-9)
        markup_denominator = max(abs(baseline_markup), 1e-9)
        cmi_denominator = max(abs(baseline_cmi), 1e-9)
        output_rows.append(
            {
                "n_bins": n_bins,
                "state_bin_edges": json.dumps(edges),
                "noise_strength": NOISE_STRENGTH,
                "baseline_mean_markup": baseline_markup,
                "noise_mean_markup": float(noise_rows["mean_markup"].mean()),
                "hard_ban_mean_markup": float(
                    ban_rows["mean_markup"].mean()
                ),
                "noise_markup_reduction_pct": noise_reduction,
                "noise_markup_reduction_ci_low": (
                    noise_markup_low / markup_denominator
                ),
                "noise_markup_reduction_ci_high": (
                    noise_markup_high / markup_denominator
                ),
                "hard_ban_markup_reduction_pct": ban_reduction,
                "hard_ban_markup_reduction_ci_low": (
                    ban_markup_low / markup_denominator
                ),
                "hard_ban_markup_reduction_ci_high": (
                    ban_markup_high / markup_denominator
                ),
                "baseline_cmi_bits": baseline_cmi,
                "noise_cmi_bits": float(noise_rows["cmi_bits"].mean()),
                "hard_ban_cmi_bits": float(ban_rows["cmi_bits"].mean()),
                "noise_cmi_reduction_pct": noise_cmi_reduction,
                "noise_cmi_reduction_ci_low": (
                    noise_cmi_low / cmi_denominator
                ),
                "noise_cmi_reduction_ci_high": (
                    noise_cmi_high / cmi_denominator
                ),
                "hard_ban_cmi_reduction_pct": ban_cmi_reduction,
                "hard_ban_cmi_reduction_ci_low": (
                    ban_cmi_low / cmi_denominator
                ),
                "hard_ban_cmi_reduction_ci_high": (
                    ban_cmi_high / cmi_denominator
                ),
                "noise_mean_z": float(noise_rows["cmi_z"].mean()),
                "hard_ban_mean_z": float(ban_rows["cmi_z"].mean()),
                "noise_flag_rate": float(noise_rows["cmi_flagged"].mean()),
                "hard_ban_flag_rate": float(ban_rows["cmi_flagged"].mean()),
                "noise_frozen_share": float(noise_rows["cmi_frozen"].mean()),
                "hard_ban_frozen_share": float(ban_rows["cmi_frozen"].mean()),
                "noise_beats_hard_ban_markup": bool(
                    noise_reduction > ban_reduction
                ),
                "noise_beats_hard_ban_cmi": bool(
                    noise_cmi_reduction > ban_cmi_reduction
                ),
                "winner_by_markup": (
                    "noise_0.40"
                    if noise_reduction > ban_reduction
                    else "hard_ban"
                ),
            }
        )
    result = pd.DataFrame(output_rows)
    result.to_csv(RESULTS_DIR / "bin_sensitivity.csv", index=False)
    return result


def run_all() -> dict[str, Any]:
    """Run all V6 robustness checks and write the machine-readable summary."""

    e3 = run_e3_consistency()
    bins = run_bin_sensitivity()
    welfare = write_welfare_sensitivity_outputs()
    summary = {
        "version": "v6",
        "e3_consistency": e3.iloc[0].to_dict(),
        "bin_sensitivity": bins.to_dict("records"),
        "noise_wins_markup_at_all_bin_counts": bool(
            bins["noise_beats_hard_ban_markup"].all()
        ),
        "welfare_sensitivity": welfare.to_dict("records"),
    }
    (RESULTS_DIR / "v6_robustness_summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False),
        encoding="ascii",
    )
    return summary


if __name__ == "__main__":
    result = run_all()
    print(json.dumps(result, indent=2, allow_nan=False))
