"""Calibrated causal collusion simulation."""

