"""Optional domain-shift diagnostic for separately supplied real states."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from config import FEATURES, RESULTS_DIR, SEED
from deferred.llm_track.common import load_behavior


def ks_stats(synthetic: pd.DataFrame, real: pd.DataFrame) -> dict[str, dict]:
    """Kolmogorov-Smirnov comparisons for each model feature."""

    result = {}
    for feature in FEATURES:
        test = ks_2samp(synthetic[feature], real[feature])
        result[feature] = {
            "statistic": float(test.statistic),
            "p_value": float(test.pvalue),
        }
    return result


def domain_classifier(
    synthetic: pd.DataFrame,
    real: pd.DataFrame,
) -> dict:
    """Train a classifier to distinguish synthetic from real market states."""

    common = [feature for feature in FEATURES if feature in real.columns]
    if len(common) < 3:
        raise ValueError("Real data must contain at least three model features")
    x_synthetic = synthetic[common].copy()
    x_real = real[common].copy()
    x_synthetic["is_real"] = 0
    x_real["is_real"] = 1
    frame = pd.concat([x_synthetic, x_real], ignore_index=True)
    x = frame[common].to_numpy(dtype=float)
    y = frame["is_real"].to_numpy(dtype=int)
    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.30,
        random_state=SEED,
        stratify=y,
    )
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "model",
                LogisticRegression(
                    max_iter=2_000,
                    class_weight="balanced",
                    random_state=SEED,
                ),
            ),
        ]
    ).fit(x_train, y_train)
    probability = model.predict_proba(x_test)[:, 1]
    prediction = (probability >= 0.5).astype(int)
    return {
        "status": "computed",
        "auc": float(roc_auc_score(y_test, probability)),
        "accuracy": float(accuracy_score(y_test, prediction)),
        "n_synthetic": int(len(synthetic)),
        "n_real": int(len(real)),
        "features": common,
    }


def write_domain_shift(real_path: Path | None = None) -> dict:
    """Write results/domain_shift.json without using real data elsewhere."""

    synthetic = load_behavior()
    if real_path is None or not real_path.exists():
        result = {
            "status": "skipped",
            "reason": "No real-state CSV supplied. Real data is coverage-only.",
            "n_synthetic": int(len(synthetic)),
        }
    else:
        real = pd.read_csv(real_path)
        result = {
            **domain_classifier(synthetic, real),
            "ks_stats": ks_stats(synthetic, real),
            "real_path": str(real_path),
        }
    (RESULTS_DIR / "domain_shift.json").write_text(
        json.dumps(result, indent=2),
        encoding="ascii",
    )
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--real-data", type=Path, default=None)
    args = parser.parse_args()
    result = write_domain_shift(args.real_data)
    print(json.dumps(result, indent=2))
    if result["status"] == "skipped":
        synthetic = load_behavior()
        shifted = synthetic.copy()
        for feature in FEATURES:
            shifted[feature] = shifted[feature] + 2.0
        gate = domain_classifier(synthetic, shifted)
        assert gate["auc"] > 0.9
        print("Coverage sanity check passed on synthetic shift")
