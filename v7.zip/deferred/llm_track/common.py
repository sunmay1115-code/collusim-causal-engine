"""Shared loading, splitting, sampling, and bootstrap utilities."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from config import (
    CI_LEVEL,
    EPSILON,
    FEATURES,
    MODELS,
    RESULTS_DIR,
    SEED,
    STRATEGIES,
    TEST_SIZE,
)


def load_behavior(path: Path | None = None) -> pd.DataFrame:
    """Load and validate the LLM behavior table."""

    source = path or RESULTS_DIR / "llm_behavior.csv"
    frame = pd.read_csv(source)
    required = {
        "dataset_version",
        "run_id",
        "row_id",
        "state_id",
        "model_name",
        "llm_price",
        "competitor_price",
        "own_price",
        "demand",
        "round_norm",
        "lagged_demand",
        "market_mean_price",
        "strategy",
        "prompt",
        "prompt_sha256",
        "raw_output",
        "is_valid",
        "data_source",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Behavior data missing columns: {sorted(missing)}")
    if not set(frame["strategy"]).issubset(STRATEGIES):
        raise ValueError("Behavior data contains unknown strategy labels")
    return frame


def make_split(
    frame: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return the common 70/30 split, stratified on strategy."""

    train, test = train_test_split(
        frame,
        test_size=TEST_SIZE,
        random_state=SEED,
        stratify=frame["strategy"],
    )
    return train.reset_index(drop=True), test.reset_index(drop=True)


def write_split_manifest() -> None:
    """Record the exact shared split for auditability."""

    frame = load_behavior()
    train, test = make_split(frame)
    strategy_counts = {
        f"{model}|{strategy}": int(count)
        for (model, strategy), count in frame.groupby(
            ["model_name", "strategy"]
        ).size().items()
    }
    manifest = {
        "dataset_run_id": str(frame["run_id"].iloc[0]),
        "data_source": str(frame["data_source"].iloc[0]),
        "seed": SEED,
        "test_size": TEST_SIZE,
        "stratified_on": "strategy",
        "train_rows": int(len(train)),
        "test_rows": int(len(test)),
        "train_state_ids": sorted(train["state_id"].unique().tolist()),
        "test_state_ids": sorted(test["state_id"].unique().tolist()),
        "models": list(MODELS),
        "features": FEATURES,
        "strategy_counts": strategy_counts,
    }
    (RESULTS_DIR / "split_manifest.json").write_text(
        json.dumps(manifest, indent=2),
        encoding="ascii",
    )


def generate_states(n_states: int, seed: int = SEED) -> pd.DataFrame:
    """Generate deterministic market states shared by all models."""

    rng = np.random.default_rng(seed)
    competitor = rng.uniform(1.0, 3.0, size=n_states)
    own = np.clip(
        competitor + rng.normal(0.0, 0.35, size=n_states),
        1.0,
        3.0,
    )
    demand = np.clip(
        50.0
        + 22.0 * (competitor - own)
        + rng.normal(0.0, 8.0, size=n_states),
        2.0,
        98.0,
    )
    lagged = np.roll(demand, 1)
    lagged[0] = demand[0]
    market_mean = np.clip(
        (competitor + own) / 2.0 + rng.normal(0.0, 0.15, size=n_states),
        1.0,
        3.0,
    )
    return pd.DataFrame(
        {
            "state_id": np.arange(n_states),
            "competitor_price": competitor,
            "own_price": own,
            "demand": demand,
            "round_norm": np.linspace(0.0, 1.0, n_states),
            "lagged_demand": lagged,
            "market_mean_price": market_mean,
        }
    )


def derive_strategy(
    llm_price: float,
    competitor_price: float,
    epsilon: float = EPSILON,
) -> str:
    """Map a numeric price decision to the three-class strategy label."""

    if llm_price < competitor_price - epsilon:
        return "undercut"
    if llm_price > competitor_price + epsilon:
        return "overcut"
    return "match"


def bootstrap_ci(
    values,
    statistic=np.mean,
    n_boot: int = 1000,
    ci: float = CI_LEVEL,
    seed: int = SEED,
) -> tuple[float, float, float]:
    """Percentile bootstrap interval for a scalar statistic."""

    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return float("nan"), float("nan"), float("nan")
    point = float(statistic(array))
    rng = np.random.default_rng(seed)
    estimates = np.empty(n_boot, dtype=float)
    for index in range(n_boot):
        sample = rng.choice(array, size=array.size, replace=True)
        estimates[index] = float(statistic(sample))
    tail = (1.0 - ci) / 2.0
    low, high = np.quantile(estimates, [tail, 1.0 - tail])
    return point, float(low), float(high)

