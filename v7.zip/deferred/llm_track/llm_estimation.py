"""Estimation layer: effect sizes and uncertainty intervals."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.proportion import proportion_confint

from config import (
    CI_LEVEL,
    FEATURES,
    MODELS,
    N_BOOTSTRAP,
    RESULTS_DIR,
    SEED,
    STRATEGIES,
)
from deferred.llm_track.common import (
    bootstrap_ci,
    load_behavior,
)


TERMS = ["competitor_price", "own_price", "demand", "round_norm"]


def _design(frame: pd.DataFrame, terms: list[str]) -> tuple[np.ndarray, np.ndarray]:
    x = sm.add_constant(frame[terms].to_numpy(dtype=float), has_constant="add")
    y = frame["llm_price"].to_numpy(dtype=float)
    return x, y


def _fit_terms(
    frame: pd.DataFrame,
    terms: list[str],
    indices: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    sample = frame if indices is None else frame.iloc[indices]
    x, y = _design(sample, terms)
    result = sm.OLS(y, x).fit()
    coef = np.asarray(result.params, dtype=float)
    x_std = x[:, 1:].std(axis=0, ddof=0)
    y_std = y.std(ddof=0)
    standardized = coef[1:] * x_std / max(y_std, 1e-12)
    return coef, standardized, np.asarray(result.bse, dtype=float)


def anchoring_regression(
    frame: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Fit simple and multiple price regressions for each model."""

    frame = load_behavior() if frame is None else frame
    rows = []
    rng = np.random.default_rng(SEED)
    for model_name, model_frame in frame.groupby("model_name"):
        model_frame = model_frame.reset_index(drop=True)
        for specification, terms in (
            ("simple", ["competitor_price"]),
            ("multiple", TERMS),
        ):
            coef, std_coef, _ = _fit_terms(model_frame, terms)
            samples = np.empty((N_BOOTSTRAP, len(coef)), dtype=float)
            for index in range(N_BOOTSTRAP):
                draw = rng.integers(0, len(model_frame), size=len(model_frame))
                samples[index] = _fit_terms(model_frame, terms, draw)[0]
            tail = (1.0 - CI_LEVEL) / 2.0
            low, high = np.quantile(samples, [tail, 1.0 - tail], axis=0)
            for term_index, term in enumerate(["const", *terms]):
                rows.append(
                    {
                        "model_name": model_name,
                        "specification": specification,
                        "term": term,
                        "coef": float(coef[term_index]),
                        "ci_low": float(low[term_index]),
                        "ci_high": float(high[term_index]),
                        "std_coef": (
                            0.0
                            if term == "const"
                            else float(std_coef[term_index - 1])
                        ),
                        "n": int(len(model_frame)),
                    }
                )
    result = pd.DataFrame(rows)
    result.to_csv(RESULTS_DIR / "estimation_anchoring.csv", index=False)
    return result


def cooperation_rates(
    frame: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Report strategy proportions with Wilson score intervals."""

    frame = load_behavior() if frame is None else frame
    alpha = 1.0 - CI_LEVEL
    rows = []
    for model_name, model_frame in frame.groupby("model_name"):
        n = len(model_frame)
        for strategy in STRATEGIES:
            successes = int((model_frame["strategy"] == strategy).sum())
            low, high = proportion_confint(
                successes,
                n,
                alpha=alpha,
                method="wilson",
            )
            rows.append(
                {
                    "model_name": model_name,
                    "strategy": strategy,
                    "proportion": successes / max(n, 1),
                    "ci_low": float(low),
                    "ci_high": float(high),
                    "n": n,
                }
            )
    result = pd.DataFrame(rows)
    result.to_csv(RESULTS_DIR / "estimation_rates.csv", index=False)
    return result


def model_differences(
    frame: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Bootstrap model-to-model differences on common market states."""

    frame = load_behavior() if frame is None else frame
    model_frames = {
        model: frame.loc[frame["model_name"] == model].reset_index(drop=True)
        for model in MODELS
    }
    state_ids = np.sort(frame["state_id"].unique())
    row_lookup = {}
    for model, model_frame in model_frames.items():
        lookup = np.full(int(max(state_ids)) + 1, -1, dtype=int)
        lookup[model_frame["state_id"].to_numpy(dtype=int)] = np.arange(
            len(model_frame)
        )
        if (lookup[state_ids.astype(int)] < 0).any():
            raise ValueError(f"Missing states for model {model}")
        row_lookup[model] = lookup
    rng = np.random.default_rng(SEED)
    coef_diff = []
    rate_diff = []
    for _ in range(N_BOOTSTRAP):
        draw = rng.choice(state_ids, size=len(state_ids), replace=True)
        positions_a = row_lookup[MODELS[0]][draw.astype(int)]
        positions_b = row_lookup[MODELS[1]][draw.astype(int)]
        coef_a = float(
            _fit_terms(model_frames[MODELS[0]], TERMS, positions_a)[0][1]
        )
        coef_b = float(
            _fit_terms(model_frames[MODELS[1]], TERMS, positions_b)[0][1]
        )
        rate_a = float(
            (
                model_frames[MODELS[0]]
                .iloc[positions_a]["strategy"]
                .eq("match")
                .mean()
            )
        )
        rate_b = float(
            (
                model_frames[MODELS[1]]
                .iloc[positions_b]["strategy"]
                .eq("match")
                .mean()
            )
        )
        coef_diff.append(coef_a - coef_b)
        rate_diff.append(rate_a - rate_b)

    rows = []
    observed = {
        "anchoring_coefficient": float(
            _fit_terms(model_frames[MODELS[0]], TERMS)[0][1]
            - _fit_terms(model_frames[MODELS[1]], TERMS)[0][1]
        ),
        "match_rate": float(
            (
                model_frames[MODELS[0]]["strategy"].eq("match").mean()
                - model_frames[MODELS[1]]["strategy"].eq("match").mean()
            )
        ),
    }
    tail = (1.0 - CI_LEVEL) / 2.0
    for quantity, values in (
        ("anchoring_coefficient", coef_diff),
        ("match_rate", rate_diff),
    ):
        low, high = np.quantile(values, [tail, 1.0 - tail])
        rows.append(
            {
                "quantity": quantity,
                "model_a": MODELS[0],
                "model_b": MODELS[1],
                "estimate": observed[quantity],
                "ci_low": float(low),
                "ci_high": float(high),
                "n_bootstrap": N_BOOTSTRAP,
            }
        )
    result = pd.DataFrame(rows)
    result.to_csv(RESULTS_DIR / "estimation_model_differences.csv", index=False)
    return result


def _validation_dataset(n: int = 1_200, seed: int = 19) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    competitor = rng.uniform(1.0, 3.0, size=n)
    own = rng.uniform(1.0, 3.0, size=n)
    demand = rng.uniform(0.0, 100.0, size=n)
    round_norm = rng.uniform(size=n)
    price = 0.30 + 0.70 * competitor + rng.normal(0.0, 0.25, size=n)
    strategy = np.where(
        price < competitor - 0.05,
        "undercut",
        np.where(price > competitor + 0.05, "overcut", "match"),
    )
    return pd.DataFrame(
        {
            "model_name": MODELS[0],
            "competitor_price": competitor,
            "own_price": own,
            "demand": demand,
            "round_norm": round_norm,
            "llm_price": price,
            "strategy": strategy,
        }
    )


if __name__ == "__main__":
    validation = _validation_dataset()
    coef, _, _ = _fit_terms(validation, ["competitor_price"])
    recovered = float(coef[1])
    _, low, high = bootstrap_ci(
        [
            _fit_terms(
                validation,
                ["competitor_price"],
                np.random.default_rng(index).integers(
                    0, len(validation), len(validation)
                ),
            )[0][1]
            for index in range(300)
        ]
    )
    print(f"Recovered beta: {recovered:.3f} CI [{low:.3f}, {high:.3f}]")
    assert abs(recovered - 0.7) <= 0.1
    assert low <= 0.7 <= high
    print("Estimation sanity check passed")
