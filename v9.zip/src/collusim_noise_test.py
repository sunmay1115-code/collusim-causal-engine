"""Standalone live-API noise ablation for the Collusim OLS proxy."""

from __future__ import annotations

import argparse
import json

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from config import CI_LEVEL, COLLUSIM_MARKET, RESULTS_DIR, ROOT, SEED
from deferred.llm_track.common import bootstrap_ci
from src.collusim.agents import CalibratedLLMProxy, RuleBasedHumanAgent
from src.collusim.environment import (
    _load_params,
    _softmax_prices,
    _welfare,
)
from src.detection.cmi_wrapper import screen_prices


LIVE_DATA_PATH = ROOT / "data" / "experimental" / "live_llm_data.csv"
ABLATION_PATH = RESULTS_DIR / "live_noise_ablation.csv"
SUMMARY_PATH = RESULTS_DIR / "live_noise_ablation_summary.json"
FIGURE_PATH = RESULTS_DIR / "figures" / "live_noise_frontier.png"
N_SEEDS = 20


class LiveNoiseAgent(CalibratedLLMProxy):
    """V6 OLS proxy plus the empirical residual noise from live API data."""

    def __init__(
        self,
        *,
        agent_id: int,
        params: dict,
        market: dict,
        seed: int,
        live_noise_std: float,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            params=params,
            market=market,
            seed=seed,
        )
        self.live_noise_std = float(live_noise_std)
        self.live_rng = np.random.default_rng(seed + 30_013 * (agent_id + 1))

    def choose_price(
        self,
        observed_competitor_price: float,
        own_last_price: float,
        blind: bool = False,
    ) -> float:
        ols_prediction = super().choose_price(
            observed_competitor_price=observed_competitor_price,
            own_last_price=own_last_price,
            blind=blind,
        )
        noisy_prediction = ols_prediction + self.live_rng.normal(
            0.0,
            self.live_noise_std,
        )
        return float(
            np.clip(
                noisy_prediction,
                self.market["p_min"],
                self.market["p_max"],
            )
        )


def estimate_live_noise(
    data_path: Path = LIVE_DATA_PATH,
) -> dict[str, float]:
    frame = pd.read_csv(data_path)
    frame = frame.loc[frame["valid_action"]].copy()
    params = _load_params()
    prediction = float(params["intercept"]) + float(params["beta"]) * frame[
        "competitor_price"
    ]
    residuals = frame["llm_action"].to_numpy(dtype=float) - prediction.to_numpy()
    return {
        "n_observations": int(len(residuals)),
        "mean_residual": float(np.mean(residuals)),
        "noise_std": float(np.std(residuals, ddof=1)),
        "noise_variance": float(np.var(residuals, ddof=1)),
        "residual_min": float(np.min(residuals)),
        "residual_max": float(np.max(residuals)),
    }


def _run_episode(
    *,
    seed: int,
    precision: float,
    live_noise_std: float,
    agent_type: str,
) -> dict:
    calibrated = _load_params()
    market = dict(COLLUSIM_MARKET)
    n_agents = market["n_agents"]
    n_rounds = market["n_rounds"]
    rng = np.random.default_rng(seed)
    if agent_type == "human":
        agents = [
            RuleBasedHumanAgent(
                agent_id=index,
                market=market,
                seed=seed,
            )
            for index in range(n_agents)
        ]
    else:
        agents = [
            LiveNoiseAgent(
                agent_id=index,
                params=calibrated,
                market=market,
                seed=seed,
                live_noise_std=live_noise_std,
            )
            for index in range(n_agents)
        ]
    history = [np.full(n_agents, market["initial_price"], dtype=float)]
    prices_log = np.empty((n_rounds, n_agents), dtype=float)
    welfare_log = np.empty(n_rounds, dtype=float)
    profit_log = np.empty((n_rounds, n_agents), dtype=float)
    blind_log = np.zeros((n_rounds, n_agents), dtype=bool)
    for period in range(n_rounds):
        chosen = np.empty(n_agents, dtype=float)
        own_last = history[-1]
        precision_reliability = 1.0 / (1.0 + 4.0 * precision)
        for agent_id in range(n_agents):
            rivals = np.delete(own_last, agent_id)
            observed = (
                float(np.mean(rivals))
                if rivals.size
                else own_last[agent_id]
            )
            observed += rng.laplace(0.0, precision)
            observed = market["c"] + precision_reliability * (
                observed - market["c"]
            )
            blind = bool(rng.random() < 0.0)
            blind_log[period, agent_id] = blind
            chosen[agent_id] = agents[agent_id].choose_price(
                observed_competitor_price=observed,
                own_last_price=float(own_last[agent_id]),
                blind=blind,
            )
        prices = np.clip(chosen, market["p_min"], market["p_max"])
        liquidity = (
            market["human_liquidity"] if agent_type == "human" else 1.0
        )
        demand = market["M"] * liquidity * _softmax_prices(prices, market)
        profit = (prices - market["c"]) * demand
        history.append(prices)
        prices_log[period] = prices
        profit_log[period] = profit
        welfare_log[period] = _welfare(prices, demand, market)
    producer_profit = float(profit_log.sum(axis=1).mean())
    total_welfare = float(np.mean(welfare_log))
    cmi = screen_prices(
        prices_log,
        hold_threshold=0.01,
        n_perm=200,
        seed=seed,
    )
    return {
        "mean_price": float(prices_log.mean()),
        "mean_markup": float(
            np.mean(
                (prices_log - market["c"]) / market["c"]
            )
        ),
        "total_welfare": total_welfare,
        "consumer_welfare": float(total_welfare - producer_profit),
        "producer_profit": producer_profit,
        "blind_share": float(blind_log.mean()),
        "cmi_bits": float(cmi["cmi_bits"]),
        "cmi_z": float(cmi["z"]),
        "cmi_flagged": bool(cmi["flagged"]),
    }


def _bootstrap_gap(
    frame: pd.DataFrame,
    treatment: str,
    seed: int,
) -> tuple[float, float, float]:
    baseline = frame.loc[
        frame["condition"] == "baseline",
        ["seed", "mean_markup"],
    ].set_index("seed")
    condition = frame.loc[
        frame["condition"] == treatment,
        ["seed", "mean_markup"],
    ].set_index("seed")
    values = (
        baseline["mean_markup"] - condition["mean_markup"]
    )
    return bootstrap_ci(
        values,
        n_boot=5_000,
        ci=CI_LEVEL,
        seed=seed,
    )


def _bootstrap_contrast(
    frame: pd.DataFrame,
    left_condition: str,
    right_condition: str,
    seed: int,
) -> tuple[float, float, float]:
    left = frame.loc[
        frame["condition"] == left_condition,
        ["seed", "mean_markup"],
    ].set_index("seed")
    right = frame.loc[
        frame["condition"] == right_condition,
        ["seed", "mean_markup"],
    ].set_index("seed")
    return bootstrap_ci(
        left["mean_markup"] - right["mean_markup"],
        n_boot=5_000,
        ci=CI_LEVEL,
        seed=seed,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=int, default=N_SEEDS)
    args = parser.parse_args()
    if args.seeds != 20:
        raise ValueError("This ablation is defined for exactly 20 paired seeds")

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_PATH.parent.mkdir(parents=True, exist_ok=True)
    noise = estimate_live_noise()
    rows: list[dict] = []
    for index in range(args.seeds):
        seed = SEED + index
        for condition, precision, agent_type in (
            ("baseline", 0.0, "llm"),
            ("noise_0.40", 0.40, "llm"),
            ("hard_ban", 0.0, "human"),
        ):
            result = _run_episode(
                seed=seed,
                precision=precision,
                live_noise_std=noise["noise_std"],
                agent_type=agent_type,
            )
            rows.append(
                {
                    "seed": seed,
                    "condition": condition,
                    "precision": precision,
                    "agent_type": agent_type,
                    "live_noise_std": noise["noise_std"],
                    **result,
                }
            )
    frame = pd.DataFrame(rows)
    baseline = frame.loc[frame["condition"] == "baseline"].set_index("seed")
    for condition in ("noise_0.40", "hard_ban"):
        mask = frame["condition"] == condition
        condition_rows = frame.loc[mask].set_index("seed")
        frame.loc[mask, "markup_reduction"] = (
            baseline["mean_markup"] - condition_rows["mean_markup"]
        ).to_numpy()
        frame.loc[mask, "welfare_change"] = (
            baseline["total_welfare"] - condition_rows["total_welfare"]
        ).to_numpy()
    frame.loc[frame["condition"] == "baseline", "markup_reduction"] = 0.0
    frame.loc[frame["condition"] == "baseline", "welfare_change"] = 0.0
    frame.to_csv(ABLATION_PATH, index=False)

    noise_ci = _bootstrap_gap(
        frame,
        "noise_0.40",
        SEED + 51,
    )
    ban_ci = _bootstrap_gap(
        frame,
        "hard_ban",
        SEED + 52,
    )
    noise_minus_ban = _bootstrap_contrast(
        frame,
        "noise_0.40",
        "hard_ban",
        SEED + 53,
    )
    summary = {
        "version": "v9",
        "paired_seeds": args.seeds,
        "live_noise": noise,
        "noise_0_40_markup_reduction": {
            "point": float(noise_ci[0]),
            "ci_low": float(noise_ci[1]),
            "ci_high": float(noise_ci[2]),
        },
        "hard_ban_markup_reduction": {
            "point": float(ban_ci[0]),
            "ci_low": float(ban_ci[1]),
            "ci_high": float(ban_ci[2]),
        },
        "noise_0_40_minus_hard_ban_markup": {
            "point": float(noise_minus_ban[0]),
            "ci_low": float(noise_minus_ban[1]),
            "ci_high": float(noise_minus_ban[2]),
        },
        "condition_means": (
            frame.groupby("condition", as_index=False)
            .agg(
                mean_markup=("mean_markup", "mean"),
                mean_price=("mean_price", "mean"),
                total_welfare=("total_welfare", "mean"),
                consumer_welfare=("consumer_welfare", "mean"),
                producer_profit=("producer_profit", "mean"),
                cmi_bits=("cmi_bits", "mean"),
            )
            .to_dict("records")
        ),
    }
    SUMMARY_PATH.write_text(
        json.dumps(summary, indent=2, allow_nan=False),
        encoding="ascii",
    )

    colors = {
        "baseline": "#64748B",
        "noise_0.40": "#0F766E",
        "hard_ban": "#C2410C",
    }
    labels = {
        "baseline": "OLS baseline",
        "noise_0.40": "Noise injection 0.40",
        "hard_ban": "Hard ban",
    }
    figure, axis = plt.subplots(figsize=(8.6, 4.8))
    for condition, part in frame.groupby("condition"):
        axis.scatter(
            part["consumer_welfare"],
            part["producer_profit"],
            s=42,
            alpha=0.62,
            color=colors[condition],
            label=labels[condition],
            edgecolor="white",
            linewidth=0.5,
        )
        axis.scatter(
            [part["consumer_welfare"].mean()],
            [part["producer_profit"].mean()],
            marker="*",
            s=220,
            color=colors[condition],
            edgecolor="#17211F",
            linewidth=0.8,
            zorder=4,
        )
    axis.set_xlabel("Consumer surplus (mean)")
    axis.set_ylabel("Producer profit (mean)")
    axis.set_title("Live-noise policy frontier")
    axis.grid(color="#DCE4E1", linewidth=0.6, alpha=0.8)
    axis.legend(frameon=False)
    axis.text(
        0.02,
        0.05,
        (
            "Empirical API noise turns the policy frontier into a mushy cloud.\n"
            f"Direct mean-markup contrast: {noise_minus_ban[0]:+.3f} "
            f"[{noise_minus_ban[1]:+.3f}, {noise_minus_ban[2]:+.3f}]."
        ),
        transform=axis.transAxes,
        fontsize=8.2,
        color="#334155",
    )
    figure.tight_layout()
    figure.savefig(FIGURE_PATH, dpi=220)
    plt.close(figure)

    print(json.dumps(summary, indent=2, allow_nan=False))
    print(f"Wrote {ABLATION_PATH}")
    print(f"Wrote {FIGURE_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
