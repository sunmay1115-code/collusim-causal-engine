"""Tests for the standalone V9 live-noise ablation."""

from __future__ import annotations

import json

import pandas as pd

from config import RESULTS_DIR
from src.collusim_noise_test import estimate_live_noise


def test_live_noise_is_empirical_and_nonzero() -> None:
    estimate = estimate_live_noise()
    assert estimate["n_observations"] >= 1_000
    assert estimate["noise_std"] > 0.20
    assert estimate["noise_variance"] > 0.04


def test_noise_ablation_has_paired_arms() -> None:
    frame = pd.read_csv(RESULTS_DIR / "live_noise_ablation.csv")
    assert len(frame) == 60
    assert set(frame["condition"]) == {
        "baseline",
        "noise_0.40",
        "hard_ban",
    }
    assert frame.groupby("condition")["seed"].nunique().eq(20).all()


def test_noise_ablation_summary_and_figure_exist() -> None:
    summary = json.loads(
        (RESULTS_DIR / "live_noise_ablation_summary.json").read_text(
            encoding="ascii"
        )
    )
    assert summary["paired_seeds"] == 20
    assert summary["live_noise"]["noise_std"] > 0.20
    assert (RESULTS_DIR / "figures" / "live_noise_frontier.png").exists()
