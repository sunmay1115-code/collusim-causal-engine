"""Tests for the V7 robustness artifacts."""

from __future__ import annotations

import json

import pandas as pd

from config import APP_VERSION, RESULTS_DIR


def test_v9_version_is_marked() -> None:
    assert APP_VERSION == "v9"
    assert (RESULTS_DIR.parent / "VERSION").read_text(
        encoding="ascii"
    ).strip() == "v9"


def test_detector_disclaimer_is_explicit() -> None:
    metrics = json.loads(
        (RESULTS_DIR / "detector_metrics.json").read_text(encoding="ascii")
    )
    assert metrics["disclaimer"] == (
        "AUC validated on synthetic scripted episodes only. "
        "Not validated on live LLM markets."
    )
    assert metrics["validation_scope"] == "synthetic_scripted_episodes_only"


def test_e3_consistency_reports_required_metrics() -> None:
    frame = pd.read_csv(RESULTS_DIR / "e3_consistency.csv")
    assert len(frame) == 1
    assert int(frame["source_runs"].iloc[0]) == 75
    assert 0.0 <= float(frame["flag_rate"].iloc[0]) <= 1.0
    assert pd.notna(frame["mean_z"].iloc[0])
    assert float(frame["adapter_math_match_rate"].iloc[0]) == 1.0


def test_bin_sensitivity_covers_all_bin_counts() -> None:
    frame = pd.read_csv(RESULTS_DIR / "bin_sensitivity.csv")
    assert set(frame["n_bins"]) == {4, 8, 12}
    assert frame["noise_beats_hard_ban_markup"].all()
    required = {
        "noise_markup_reduction_pct",
        "noise_markup_reduction_ci_low",
        "noise_markup_reduction_ci_high",
        "hard_ban_markup_reduction_pct",
        "noise_cmi_reduction_pct",
        "noise_cmi_reduction_ci_low",
        "noise_cmi_reduction_ci_high",
        "hard_ban_cmi_reduction_pct",
    }
    assert required.issubset(frame.columns)
    assert frame["noise_markup_reduction_ci_low"].between(0, 1).all()
    assert frame["noise_markup_reduction_ci_high"].between(0, 1).all()
    assert frame["noise_cmi_reduction_ci_low"].between(0, 1).all()
    assert frame["noise_cmi_reduction_ci_high"].between(0, 1).all()


def test_welfare_sensitivity_has_top_three_per_weight() -> None:
    frame = pd.read_csv(RESULTS_DIR / "welfare_sensitivity.csv")
    assert len(frame) == 9
    assert set(frame["weight_label"]) == {
        "consumer_50_producer_50",
        "consumer_70_producer_30",
        "consumer_30_producer_70",
    }
    counts = frame.groupby("weight_label")["rank"].apply(sorted)
    assert all(ranks == [1, 2, 3] for ranks in counts)
    assert frame["strict_gate_pass"].all()


def test_lagged_cmi_comparison_covers_every_restriction() -> None:
    frame = pd.read_csv(RESULTS_DIR / "lagged_cmi_comparison.csv")
    required = {
        "lever",
        "strength",
        "cmi_reduction_pct",
        "cmi_reduction_pct_lagged",
        "lagged_minus_contemporaneous_pp",
        "lagged_is_stronger",
    }
    assert required.issubset(frame.columns)
    assert set(frame["lever"]) == {
        "precision",
        "delay",
        "visibility",
        "history_reset",
        "hard_ban",
    }
    noise = frame.loc[
        (frame["lever"] == "precision")
        & (frame["strength"] == 0.40)
    ]
    assert len(noise) == 1
