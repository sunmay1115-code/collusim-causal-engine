# Calibrated information-theoretic collusion detection for LLM agents

AI Collusion Research Sprint (Apart Research × Poseidon Research, Oct 23–25 2026) · Track 1, **Question 1.4**:
*Can we use information-theoretic approaches to detect collusion in multi-agent games?*

Report: [`report/report.pdf`](report/report.pdf) (source: `report/report.md`).

## What is here

| Path | What it is |
|---|---|
| `infocollusion/estimators.py` | Open implementation of Bonjour et al. (UAI 2022) individual influence γ and net influence Γ, plus Miller–Madow correction, within-state permutation test, and G-test |
| `infocollusion/detect.py` | **One-call screen for any action log**: `screen(actions, states)` → per-pair CMI, net influence, permutation z/p, calibrated flag |
| `infocollusion/baselines.py` | Pearson / agreement-rate baselines, pair scoring, AUROC |
| `infocollusion/games.py` | Scripted ground-truth games: n-player RPS with assistant collusion; 4-firm market-division game with covert colluders, ex-ante rotators and same-policy "twins" |
| `infocollusion/llm_market.py` | The market-division game played by LLM agents (indep / private-channel pair / tacit pair) + LLM judge |
| `experiments/e1_rps_replication.py` | E1: replication + calibration (positive control) |
| `experiments/e2_market_scripted.py` | E2: same-model confound and auditor-state boundary |
| `experiments/e3_double_auction.py` | E3: re-analysis of Agrawal et al. (2025) double-auction logs (real GPT-4.1/Claude agents) |
| `experiments/e4_llm_market.py`, `e4_analyze.py` | E4: Qwen2.5-7B agents with a seeded secret pair |
| `experiments/figures.py`, `tables.py` | Every figure and table in the report, generated from `results/*.json` |
| `infra/modal_vllm.py` | Optional Modal vLLM endpoint (adapted from the starter repo); E4 was actually run locally with `mlx_lm.server` |
| `experiments/e4_exploratory.py` | Exploratory E4 checks quoted in §4.4 |
| `share/` | Team brief (`TEAM_BRIEF.pdf`) and the report PDF, ready to send |
| `tests/` | Estimator unit tests (analytic MI values, bias correction, permutation null) |

## Reproduce

```bash
uv sync
uv run pytest                                        # 11 tests
uv run python experiments/e1_rps_replication.py 400  # ~5 min, CPU
uv run python experiments/e2_market_scripted.py 300  # ~3 min
# E3 needs the sprint starter repo (for the released auction logs):
git clone https://github.com/poseidon-research/collusion_hackathon external/collusion_hackathon
uv run python experiments/e3_double_auction.py
# E4 needs an OpenAI-compatible endpoint; we used a local MLX server:
uv run mlx_lm.server --model mlx-community/Qwen2.5-7B-Instruct-4bit --port 8080 --decode-concurrency 16
uv run python experiments/e4_llm_market.py --games 12 --rounds 20
uv run python experiments/e4_analyze.py
uv run python experiments/figures.py && uv run python experiments/tables.py
uv run python report/build.py                        # needs Google Chrome for the PDF
```

## Pre-existing work and data

All code in this repository was written during the sprint. No pre-sprint code is included.
`external/collusion_hackathon` (not committed) is the official sprint starter repository; we only read the
released Agrawal et al. auction logs from it, unchanged. `infra/modal_vllm.py` is adapted from the starter repo's
`poseidon_compute.modal_serve`.
