"""OpenAI-compatible vLLM endpoint on Modal for the LLM-agent experiments.

Adapted from poseidon_compute.modal_serve in the sprint starter repo (adds a weight cache volume and
request concurrency). Deploy:  uv run modal deploy infra/modal_vllm.py
Stop:                          uv run modal app stop collusion-q14-vllm
The container scales to zero after 5 idle minutes, so a deployed-but-unused app costs nothing.
"""
import os
import subprocess

import modal

MODEL = os.environ.get("MODAL_SERVE_MODEL", "Qwen/Qwen2.5-14B-Instruct")
GPU = os.environ.get("MODAL_SERVE_GPU", "L40S")
PORT = 8000

app = modal.App("collusion-q14-vllm")

image = (
    modal.Image.debian_slim(python_version="3.12")
    .pip_install("vllm==0.9.1", "huggingface_hub[hf_transfer]==0.32.0")
    .env({"HF_HUB_ENABLE_HF_TRANSFER": "1"})
)
hf_cache = modal.Volume.from_name("collusion-q14-hf-cache", create_if_missing=True)
vllm_cache = modal.Volume.from_name("collusion-q14-vllm-cache", create_if_missing=True)


@app.function(
    image=image,
    gpu=GPU,
    timeout=6 * 3600,
    scaledown_window=300,
    volumes={"/root/.cache/huggingface": hf_cache, "/root/.cache/vllm": vllm_cache},
)
@modal.concurrent(max_inputs=128)
@modal.web_server(port=PORT, startup_timeout=1200)
def serve():
    cmd = [
        "vllm", "serve", MODEL,
        "--host", "0.0.0.0", "--port", str(PORT),
        "--served-model-name", MODEL,
        "--max-model-len", "8192",
        "--gpu-memory-utilization", "0.92",
    ]
    subprocess.Popen(" ".join(cmd), shell=True)
