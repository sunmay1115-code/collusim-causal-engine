import numpy as np
import pytest

from infocollusion.estimators import (
    _within_state_permutation, bonjour_detect, conditional_mi, encode, influence_matrix,
    net_influence, permutation_test,
)


def test_identical_uniform_variables_have_log3_mi():
    x = np.tile([0, 1, 2], 1000)
    assert conditional_mi(x, x) == pytest.approx(np.log(3), abs=1e-9)


def test_independent_product_table_has_zero_mi():
    # every (x, y) combination exactly once -> empirical joint factorises
    x, y = np.meshgrid(np.arange(3), np.arange(3))
    assert conditional_mi(x.ravel(), y.ravel()) == pytest.approx(0.0, abs=1e-12)


def test_conditioning_removes_common_cause():
    rng = np.random.default_rng(1)
    s = rng.integers(0, 3, 20000)
    x, y = s.copy(), s.copy()          # both are deterministic functions of the shared state
    assert conditional_mi(x, y) == pytest.approx(np.log(3), abs=0.01)
    assert conditional_mi(x, y, s) == pytest.approx(0.0, abs=1e-12)


def test_matches_analytic_mi_of_noisy_channel():
    # y = x with prob 0.3 else uniform -> P(y=x)=0.533..
    rng = np.random.default_rng(2)
    x = rng.integers(0, 3, 400000)
    y = np.where(rng.random(x.size) < 0.3, x, rng.integers(0, 3, x.size))
    q = 0.3 + 0.7 / 3
    r = 0.7 / 3
    analytic = np.log(3) + q * np.log(q) + 2 * r * np.log(r)
    assert conditional_mi(x, y) == pytest.approx(analytic, abs=0.002)


def test_miller_madow_reduces_small_sample_bias():
    rng = np.random.default_rng(3)
    plug, mm = [], []
    for _ in range(300):
        x, y = rng.integers(0, 3, 30), rng.integers(0, 3, 30)
        plug.append(conditional_mi(x, y))
        mm.append(conditional_mi(x, y, miller_madow=True))
    assert np.mean(plug) > 0.04
    assert abs(np.mean(mm)) < abs(np.mean(plug)) / 3


def test_within_state_permutation_preserves_states():
    rng = np.random.default_rng(4)
    s = rng.integers(0, 5, 200)
    perm = _within_state_permutation(s, rng)
    assert sorted(perm) == list(range(200))
    assert np.array_equal(s[perm], s)
    assert not np.array_equal(perm, np.arange(200))


def test_permutation_test_separates_signal_from_noise():
    rng = np.random.default_rng(5)
    x = rng.integers(0, 3, 300)
    y_dep = np.where(rng.random(300) < 0.5, (x + 1) % 3, rng.integers(0, 3, 300))
    y_ind = rng.integers(0, 3, 300)
    assert permutation_test(x, y_dep, n_perm=200, rng=rng).p < 0.01
    assert permutation_test(x, y_ind, n_perm=200, rng=rng).p > 0.01


def test_net_influence_and_bonjour_rule_find_the_pair():
    g = np.array([[0, .2, .01], [.2, 0, .02], [.01, .02, 0]])
    big = net_influence(g)
    assert big[0, 1] == pytest.approx(0.2 - 0.02)
    assert big[1, 0] == pytest.approx(0.2 - 0.01)
    assert bonjour_detect(g, alpha=0.05) == (0, 1)
    assert bonjour_detect(g * 0.1, alpha=0.05) is None


def test_influence_matrix_symmetric():
    rng = np.random.default_rng(6)
    a = rng.integers(0, 3, (100, 4))
    g = influence_matrix(a)
    assert np.allclose(g, g.T) and np.all(np.diag(g) == 0)


def test_encode():
    assert list(encode(["b", "a", "b", "c"])) == [0, 1, 0, 2]


def test_screen_finds_planted_pair():
    from infocollusion.detect import screen
    rng = np.random.default_rng(1)
    T = 300
    a = rng.integers(0, 3, size=(T, 4))
    copy = rng.random(T) < 0.6
    a[copy, 2] = a[copy, 1]
    rows = screen(a, rng.integers(0, 2, size=(T, 2)), n_perm=200)
    assert rows[0]["pair"] == (1, 2) and rows[0]["flagged"]
    assert not any(r["flagged"] for r in rows[1:])
