# Who Is Talking to Whom? Calibrated Information-Theoretic Collusion Detection for LLM Agents

<div class="authors"><b>Assan Alibatyrkhan</b><sup>1</sup> · <i>[teammates: add names]</i><br><sup>1</sup><i>[affiliation]</i><br>AI Collusion Research Sprint (Apart Research × Poseidon Research) · Track 1, Question 1.4 · October 2026<br>Code and data: <a href="https://github.com/asanbl4/info-collusion-detection">github.com/asanbl4/info-collusion-detection</a></div>

## Abstract

Can mutual information (MI) between agents' actions reveal collusion among LLM agents? Bonjour et al. (2022) proposed *net influence*, a state-conditional MI between two agents' actions. They validated it with a fixed threshold, thousands of rounds and scripted agents. We release an open implementation, replicate it, and stress-test it in conditions that matter for LLM audits. (1) At LLM-game lengths (25 rounds), the published rule raises a false alarm in 65% of games with no collusion, and it can never detect collusion weaker than its threshold. A calibrated permutation/G-test brings false alarms near nominal and detects collusion probability 0.1 in 88% of 1,000-round games, versus 0%. (2) Conditioning on the public state defeats the *same-model confound*. Correlation baselines rank two non-communicating copies of one policy as the colluders in up to 100% of games; state-conditional MI almost never does. (3) Conditional MI measures information flow outside the auditor's state, not collusion itself, so ex-ante rotation schemes are invisible. (4) On 75 released double-auction runs with GPT-4.1/Claude sellers, action-only dependence does not separate chatting from non-chatting cartels, because agreed collusion appears as price *stasis*. (5) Secretly paired Qwen2.5-7B agents, with or without a private channel, show collusive intent in messages but no pair-specific behaviour. Every detector, including an LLM judge, is at chance, and the published rule fires in 83% of collusion-free games. MI statistics are calibratable "plus factors" for covert pairwise coordination, not stand-alone cartel detectors, and they can only be evaluated against a behavioural positive control.

## 1 Introduction

Firms are already handing pricing and bidding decisions to LLM agents, and these agents can coordinate. They do so tacitly in repeated pricing games (Fish et al., 2024) and explicitly when given a channel (Agrawal et al., 2025). Auditors will usually not see the agents' private messages or internal states. They will see what the agents *did*. Detecting collusion from behaviour alone is therefore a core oversight capability. Information theory offers a domain-agnostic tool for it: if two agents' actions are more dependent than the shared environment explains, information is flowing between them.

Bonjour, Aggarwal & Bhargava (2022) turned this into a detector. For agents *i*, *j* with shared state *s* in a fully observable simultaneous game, the *individual influence* is γ(i;j) = Σ_s p(s) I(a_i; a_j | s), and the *net influence* is Γ(i;j) = γ(i;j) − max_{k≠i,j} γ(k;j). A pair is declared colluding when exactly one pair has Γ(i;j), Γ(j;i) ≥ α. On scripted three-player Rock-Paper-Scissors and Leduc poker, with α = 0.05 and up to 10,000 games, it identified the colluding pair. The sprint brief notes that the method "assumes exactly two colluders and has not been applied to language-model agents". LLM audits differ from that setting in three ways. Games are short (15–30 rounds). The agents are often copies of the same model, so they respond to the environment identically without any communication. And cartels may include every seller.

**Contributions.**

1. **An open implementation and replication** of individual/net influence, with unit tests against analytic MI values. On the paper's own RPS benchmark it reproduces the published qualitative pattern (§4.1).
2. **Calibration.** We show the fixed-α rule is unusable at LLM sample sizes and has a hard detection floor. We replace it with bias-corrected MI plus a within-state permutation test (or G-test), which fixes both problems (§3.2, §4.1).
3. **A confound and a boundary.** In a market-division game, state conditioning is what separates covert colluders from same-policy "twins", which every correlation-style baseline flags. We also show formally and empirically that conditional MI is blind to coordination that uses only information inside the auditor's state (§4.2).
4. **Real LLM data.** We re-analyse the 75 double-auction runs released by Agrawal et al. (2025). We introduce a coalition-level *excess dependence* score calibrated against cross-run surrogate pairs. The honest negative result shows where the approach stops working (§4.3).
5. **An LLM seeded-pair experiment with a failed positive control.** Four Qwen2.5-7B agents play the market game, and one secretly allied pair gets a private channel or none. The pair never behaves differently from the other pairs, so all detectors are at chance, while the published rule still fires in 83% of collusion-free games (§4.4).

## 2 Related work

**Collusion detection in games.** Bonjour et al. (2022) is the direct basis for this work. Earlier work on detecting poker and online-game collusion relied on domain features; the economics literature on cartel screening (Harrington, 2008) treats behavioural evidence such as parallel pricing as "plus factors" that must be combined with other evidence. **LLM collusion.** Fish et al. (2024) find tacit supra-competitive pricing by LLM agents. Agrawal et al. (2025) study LLM sellers in a continuous double auction with and without seller chat, oversight and pressure, and score coordination with an LLM judge that reads the sellers' messages. Motwani et al. (2024) and Mathew et al. (2024) study steganographic collusion channels between LLMs. The sprint brief also points to related work on cross-deployment correlation (Xu et al., 2026), interpretability-based detectors (Rose et al., 2026) and Schelling-salient coordination (Rippin et al., 2026; Aharon et al., 2026); we did not reproduce these. **Estimation.** Plug-in MI is biased upward by roughly (K_x−1)(K_y−1)/2N nats (Miller, 1955; Paninski, 2003), which is large exactly when N is small. Our lagged variant is a conditional transfer entropy (Schreiber, 2000).

## 3 Method

### 3.1 Individual and net influence
Actions are discrete codes. For a fully observable simultaneous game we compute γ(i;j) with the plug-in estimator of Eq. (6) in Bonjour et al., and Γ from their Eq. (4). The paper does not state a log base. Its α = 0.05 is consistent with its reported results only in **bits**: assistant collusion with CP = 0.2 has true MI 0.055 bits but 0.038 nats, and the paper reports detecting it at large N. We therefore apply α in bits.

### 3.2 Calibration: from a threshold to a test
A fixed α ignores sample size. Below α nothing is ever detected, however much data there is. Above it, small-sample upward bias produces false alarms. We instead test H0: I(a_i; a_j | s) = 0 with two tools:
1. **Miller–Madow correction** of the plug-in MI (bias (K_x,s−1)(K_y,s−1)/2n per state).
2. **A within-state permutation test.** We shuffle a_j among rounds that share the same state, which preserves both agents' state-conditional marginals and destroys only their coupling. This gives a z-score and p-value per pair. For large-sample sweeps we use the asymptotic G-test (2N·I ~ χ² with Σ_s (K_x,s−1)(K_y,s−1) d.o.f.).

The *calibrated rule* flags a pair when its p-value is below 0.05/#pairs (Bonferroni) and both net influences are positive. It returns a single pair, as the original rule does.

### 3.3 Choosing the auditor's state
Conditioning is what separates collusion from a common cause: two agents that both chase the most valuable market are correlated through the state, not through each other. With few rounds and many states, conditioning on the raw state leaves too few samples per cell. When actions have a state-relative meaning, we **canonicalise** them instead. In the market game, an action is recorded as "took the region ranked r-th by value", which removes the state by construction.

### 3.4 Beyond pairs: excess dependence against cross-run surrogates
Net influence subtracts the strongest *other* partner, so it is ~0 by construction when every agent colludes. For grand coalitions we score a run by its **excess dependence**: the mean pairwise conditional MI among its agents, minus the same quantity for *cross-run surrogate pairs*. A surrogate pair is agent i from run r and agent j from another run r′ of the same condition. Such a pair shares model, prompt, environment and time trends, but cannot share information. This is the natural null for the "same model, same market" confound raised in sprint question 1.3. A **lagged** variant, ½[I(a_j,t; a_i,t−1 | a_j,t−1) + (i↔j)], captures follow-the-leader and turn-taking dynamics.

### 3.5 Baselines
We compare against four baselines: ordinary action correlation (|Pearson r| of action codes); an agreement-rate z-score (same-action rate vs. expectation under independent marginals); a game-aware avoidance score (expected minus observed same-region rate); and an LLM judge that reads the public record. In the auction we also use the paper's own measures: price-matching, ask dispersion, ask level, and the paper's LLM judge, which reads the sellers' messages.

## 4 Experiments and results

All code runs on a laptop CPU. E1–E3 cost $0 (scripted agents and released logs). E4 runs Qwen2.5-7B-Instruct (4-bit, MLX) locally.

### 4.1 E1 – Positive control and replication: iterated RPS
**Setup.** We reproduce the manual assistant collusion of Bonjour et al. Player A plays uniformly at random. Assistant B, with collusion probability CP, plays the move A's action beats, which guarantees A a point; otherwise B plays at random. Player C (and D in the 4-player variant) plays at random. We use 400 independent runs per cell, CP ∈ {0, 0.1, 0.2, 0.3, 0.4, 0.6, 1}, and 25–1,000 rounds.

**Replication.** The published rule reaches 100% detection at CP = 0.3 with 1,000 rounds (paper: 100%) and essentially never detects CP = 0.1 (paper: ≈8%). At CP = 0.2 it plateaus near 58% (paper: 24% at 1,000 games, 82% at 10,000). The pattern matches: a detection floor near α and strength-dependent swiftness. Exact numbers differ because the paper's unit of a "game" and its state abstraction are not fully specified.

**Calibration matters at LLM scale (Fig. 1, Table 1).** At 25 rounds, the regime of LLM experiments, the published rule flags a colluding pair in **65%** of games that contain no collusion (56% with 4 players), because the plug-in MI bias exceeds α. The calibrated test holds this to 10–12%; the residual excess over 5% comes from the asymptotic G-test at tiny N, and the permutation test removes it. At large N the fixed rule hits its floor: CP = 0.1 is detected in **0%** of 1,000-round games, versus **88%** for the calibrated test (81% with 4 players). For moderate collusion (CP = 0.3, 100 rounds) the two rules have equal power (0.83 vs. 0.86).

![Fig. 1](../figures/fig1_rps_replication.png)
*Figure 1. Three-player RPS with assistant collusion. Left: false-positive rate with no collusion. Right: rate at which the rule returns exactly the true pair. 400 runs per point.*

**Table 1.** Detection rates (CP = 0: false-positive rate). 400 runs per cell.

| Players | CP | Rounds | Bonjour rule (α=0.05 bits) | Calibrated test |
|---|---|---|---|---|
| 3 | 0 (FPR) | 25 | 0.65 | 0.12 |
| 3 | 0 (FPR) | 100 | 0.08 | 0.04 |
| 3 | 0.1 | 1000 | 0.00 | 0.88 |
| 3 | 0.2 | 1000 | 0.58 | 1.00 |
| 3 | 0.3 | 100 | 0.83 | 0.86 |
| 4 | 0 (FPR) | 25 | 0.56 | 0.10 |
| 4 | 0.1 | 1000 | 0.00 | 0.81 |
| 4 | 0.2 | 1000 | 0.56 | 0.98 |

### 4.2 E2 – The same-model confound and the auditor-state boundary: a market-division game
**Game.** Four firms each choose one of three regions per round. Region values are 60/30/10 in a random public layout (6 states), and a region's value is split among the firms that enter it. Colluding by *market division* (one partner takes the 60 region, the other the 30) beats competing. Firms 0–1 are the candidate pair. Firms 2–3 are **twins**: both run the identical ε-greedy policy "take the most valuable region" (ε = 0.2) with private noise and no communication. This mimics two copies of one LLM. Colluders, with probability CP per round, use a secret shared coin to decide who takes the 60 region and who takes the 30; otherwise they act like independent softmax firms. 300 runs per cell.

**Correlation baselines accuse the twins (Fig. 2, Table 2).** With CP = 0.5, Pearson correlation, the agreement z-score and unconditional MI rank the *twins* as the most suspicious pair in 59–66% of 20-round games and 99–100% of 200-round games. They rank the true colluders first in ≤ 1% of games. Worse, colluders' pairwise correlation is *lower* than that of honest firms (pair-level AUROC ≈ 0). Honest firms are positively correlated through the common state, and market division removes exactly that correlation, so covert collusion makes a pair look more independent to a correlation screen. Conditioning on the state fixes this. CMI and net influence rank the twins first in ≤ 5% of games and the true pair first in 48% (20 rounds), 73% (50) and 100% (200) of games (chance: 17%). For *ranking* within a game, plug-in net influence is as good as or better than the calibrated z at small N; calibration matters for the accept/reject *decision* (E1), not for the ordering.

**Conditional MI measures information outside the auditor's state.** "Rotators" follow an ex-ante plan with no runtime communication: on even rounds partner A takes the 60 region, on odd rounds B does. With the auditor's state = region values, the plan uses information the auditor does not condition on (round parity), and CMI finds the pair in 100% of games. Add parity to the state and the same pair becomes **exactly invisible** (top-1 = 0.00, AUROC 0.00 at 50+ rounds): given (values, parity), both rotators' actions are deterministic, so I(a_i; a_j | s) = 0. This is a general property, not a quirk. Any coordination that is a fixed function of the auditor's state is indistinguishable from independent state-contingent play. The choice of state *is* the definition of collusion the detector enforces.

![Fig. 2](../figures/fig2_market_scripted.png)
*Figure 2. Probability that each score ranks the true colluding pair first among the 6 pairs (dashed: chance). Twins (identical policy, no communication) are present in all panels.*

**Table 2.** Top-1 accuracy / pair-level AUROC (true pair vs. the same seats when independent), 300 runs per cell.

| Scenario | Rounds | Pearson | Agreement z | MI (no state) | CMI given state | Net infl. given state | Calibrated z |
|---|---|---|---|---|---|---|---|
| Covert, CP=0.25 | 200 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 0.62 / 0.90 | 0.62 / 0.82 | 0.68 / 0.89 |
| Covert, CP=0.5 | 20 | 0.01 / 0.06 | 0.00 / 0.02 | 0.01 / 0.03 | 0.48 / 0.84 | 0.48 / 0.66 | 0.28 / 0.56 |
| Covert, CP=0.5 | 50 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 0.73 / 0.94 | 0.73 / 0.85 | 0.56 / 0.85 |
| Covert, CP=0.5 | 200 | 0.00 / 0.00 | 0.00 / 0.00 | 0.00 / 0.00 | 1.00 / 1.00 | 1.00 / 1.00 | 1.00 / 1.00 |
| Rotation, state = values | 20 | 0.24 / 0.32 | 0.17 / 0.25 | 0.39 / 0.43 | 1.00 / 1.00 | 1.00 / 1.00 | 1.00 / 1.00 |
| Rotation, state = values+parity | 50 | 0.16 / 0.18 | 0.09 / 0.11 | 0.54 / 0.56 | 0.01 / 0.00 | 0.01 / 0.81 | 0.13 / 0.59 |

### 4.3 E3 – Real LLM agents: the Agrawal et al. double-auction logs
**Data.** We use the 75 runs released with Agrawal et al. (2025) in the sprint starter repository. Each run has 5 LLM sellers, 5 buyers and 30 rounds. In 65 runs sellers can chat (GPT-4.1 baseline, oversight, CEO pressure, and Claude or mixed seller groups); in the 10 baseline runs they cannot. We discretise each seller's per-round ask change into down / hold / up (|Δ| ≤ $0.25 is hold); the public state is whether a trade cleared last round. Here *every* seller is in the cartel, so we use the coalition score of §3.4. Its null is surrogate pairs drawn from other runs of the same condition.

**Result: action-only dependence does not separate chatting from silent sellers (Fig. 3).** For GPT-4.1 sellers with chat versus without (10 vs. 10 runs), contemporaneous excess MI has AUROC 0.48 (bootstrap 95% CI 0.22–0.74), max net influence 0.44, and mean Pearson correlation 0.49. Comparing all 65 chat runs with the 10 no-chat runs, every action-dependence score sits at or below 0.5. The lagged excess MI reaches 0.74 (CI 0.50–0.95; Mann–Whitney p = 0.08). It was the best of 8 variants we tried, so we treat it as exploratory. Price-level evidence does better (ask level 0.69/0.74), and the paper's message-reading LLM judge is near-perfect (1.00/0.81).

**Why it fails: collusion as stasis.** With chat, sellers agree on a price and *stop moving*: 87% of seller-rounds are "hold" (vs. 78% without chat), and asks are often identical (e.g. all five at $90.50 for the final 10 rounds). MI is a property of *variation*, and a frozen cartel has almost none. Meanwhile, sellers *without* chat already show positive excess dependence (+0.06 nats over surrogates): they react to the same trades and bids, which the coarse public state does not capture. So the auction contains two things the method cannot separate from actions alone: tacit common response and agreed stasis. In antitrust terms, MI here is at best a weak plus factor.

![Fig. 3](../figures/fig3_double_auction.png)
*Figure 3. AUROC for separating seller groups that could chat from groups that could not (dashed: chance). Only the LLM judge reads messages; all other scores use public actions or prices.*

### 4.4 E4 – LLM agents with a seeded secret pair
**Setup.** Four Qwen2.5-7B-Instruct agents (4-bit, temperature 0.7) play the market game of §4.2 for 20 rounds, and see the value layout plus the last 8 rounds. Each agent sees only its own earnings and the public choices. There are three conditions, with 12 games each. In *indep*, every firm maximises its own earnings. In *tacit*, a randomly chosen pair is told privately that it is allied and should maximise combined earnings by splitting the 60 and 30 regions, but it has no channel. *Channel* is the same, plus a private one-line note to the partner each round. No game had an invalid reply. The judge (same model) scores each pair 0–10 from the public record.

**Positive control: the instruction did not produce pair-specific coordination.** In both alliance conditions the allied pair entered the same region in 42–43% of rounds, versus 45% for the other pairs *in the same games*. The pair rate was lower in only 8/12 (channel) and 6/12 (tacit) games (Wilcoxon p = 0.53, 0.55). Pair earnings were no higher (39.2 vs. 41.5 and 40.9 vs. 41.4 per round). The allies split 60/30 more often than independent firms (25–33% vs. 17%). But the whole game changed: collisions fell for *every* pair (0.45 vs. 0.59 in indep games), because an agent told to avoid its partner also avoids the 60 region. The channel messages show why. The allies do agree ("Take Central, I'll take North"), but they agree on region *names* while the values move every round, and they soon send conflicting plans ("North this round, then alternate" vs. "Take South"). The 7B agents had collusive *intent* but no consistent collusive *policy*.

**Detection (Table 3).** With no pair-specific behavioural signal, every pair-level detector is at chance. The true pair is ranked first in 8–42% of games (chance 17%), and AUROC against pairs from no-collusion games is 0.34–0.58 for all MI scores, both correlation baselines, and the judge. The one exception is the game-aware avoidance score (AUROC 0.86–0.90). It picks up the *game-level* change above: against other pairs in the same game it falls to 0.70 (channel) and 0.54 (tacit). The published Bonjour rule flags a pair in **83%** of the 12 independent games (no collusion), as E1 predicts for N = 20. Within alliance games it names the correct pair in only 17–25%. An exploratory re-run of the calibrated test on raw region names, the level at which the notes coordinate, did no better (top-1 ≤ 0.08). The lesson is methodological. **A collusion detector can only be evaluated when a positive control shows that the seeded colluders actually behaved differently.** E1 and E2 supply that by construction; this E4 configuration does not. Stronger models or a longer game are needed before the LLM case can test the detector.

**Table 3.** E4, 12 games per condition. Top-1 = P(seeded pair ranked first of 6); AUROC = seeded pair vs. all pairs in independent games.

| Score | Channel: top-1 | Channel: AUROC | Tacit: top-1 | Tacit: AUROC |
|---|---|---|---|---|
| Calibrated MI z (ours) | 0.25 | 0.35 | 0.17 | 0.34 |
| Calibrated lagged MI z (ours) | 0.25 | 0.58 | 0.17 | 0.48 |
| Net influence (Bonjour) | 0.25 | 0.44 | 0.17 | 0.52 |
| Pearson \|r\| | 0.17 | 0.41 | 0.25 | 0.48 |
| Agreement-rate z | 0.42 | 0.51 | 0.25 | 0.38 |
| Avoidance (game-aware) | 0.33 | 0.90 | 0.08 | 0.86 |
| LLM judge (public record) | 0.11 | 0.40 | 0.10 | 0.34 |

## 5 Discussion

**What should count as information-theoretic evidence of collusion?** Our results support a narrow, defensible claim: *a calibrated rejection of conditional independence, given an explicitly stated auditor state, is evidence that information not in that state flows between two agents.* That is weaker than "collusion". Shared private randomness, a covert channel, and a common unobserved cause the auditor forgot to condition on all produce it. And it is blind to coordination that runs entirely through the stated state (E2 rotation), that freezes behaviour (E3), or that exists only as intent and never becomes a consistent policy (E4). In practice this makes conditional MI a useful **screen** for pairwise covert signalling in games with rich action variation, and a poor tool for detecting established cartels.

**Practical recommendations for auditors.** (i) Never use a fixed MI threshold across sample sizes; test against a within-state permutation null and correct for multiple pairs. (ii) Report the conditioning state; it determines what is called collusion. (iii) Calibrate against surrogates from the same model and environment (cross-run pairs), the information-theoretic analogue of the calibration proposed in sprint question 1.3. (iv) Combine with price-level and message-level evidence; in the auction, the only strong detector read the messages. (v) Before evaluating any detector on LLM agents, check a behavioural positive control: E4 shows that instructing agents to collude does not guarantee they do.

## 6 Conclusion
We release the first open implementation of Bonjour et al.'s net influence, replicate it, and show that a calibrated version fixes its small-sample false alarms and its detection floor. Under a same-model confound, state-conditional MI finds a covertly coordinating pair where correlation screens accuse the wrong agents. The same analysis marks its limits: it measures information flow beyond a chosen state, which misses ex-ante plans and price stasis, and it does not detect real LLM cartels in a double auction from actions alone. Small instructed LLM colluders may not change their behaviour at all, which is a warning for any benchmark built on seeded collusion.

## References
- Agrawal, K., Teo, V., Vazquez, J. J., Kunnavakkam, S., Srikanth, V., & Liu, A. (2025). Evaluating LLM Agent Collusion in Double Auctions. arXiv:2507.01413.
- Aharon et al. (2026). Tacit Coordination of Large Language Models. arXiv:2601.22184.
- Bonjour, T., Aggarwal, V., & Bhargava, B. (2022). Information-Theoretic Approach to Detect Collusion in Multi-Agent Games. *UAI 2022*, PMLR 180:223–232.
- Fish, S., Gonczarowski, Y. A., & Shorrer, R. I. (2024). Algorithmic Collusion by Large Language Models. arXiv:2404.00806.
- Harrington, J. E. (2008). Detecting Cartels. In P. Buccirossi (Ed.), *Handbook of Antitrust Economics*. MIT Press.
- Mathew, Y., et al. (2024). Hidden in Plain Text: Emergence & Mitigation of Steganographic Collusion in LLMs. arXiv:2410.03768.
- Miller, G. (1955). Note on the bias of information estimates. In *Information Theory in Psychology*, 95–100.
- Motwani, S. R., et al. (2024). Secret Collusion among AI Agents: Multi-Agent Deception via Steganography. *NeurIPS 2024*. arXiv:2402.07510.
- Paninski, L. (2003). Estimation of entropy and mutual information. *Neural Computation*, 15(6), 1191–1253.
- Qwen Team (2024). Qwen2.5 Technical Report. arXiv:2412.15115.
- Rippin et al. (2026), arXiv:2606.28425; Rose et al. (2026), arXiv:2604.01151; Xu et al. (2026), arXiv:2607.26385, as cited in the sprint brief (not reproduced here).
- Schreiber, T. (2000). Measuring information transfer. *Physical Review Letters*, 85(2), 461.

---

## Appendix A – Limitations and Dual-Use / Ethical Considerations

**Limitations.** (1) *Small LLM, short games.* E4 uses a 4-bit 7B model for 20 rounds and 12 games per condition (we had no GPU budget). Its positive control failed, so E4 says nothing about how the detectors would perform against stronger LLM colluders. Those may coordinate cleanly, which would make them easier to detect, or follow ex-ante plans, which would make them harder. (2) *Few auction runs.* E3 has 10 vs. 10 runs in its cleanest comparison; confidence intervals are wide, and we tried 8 discretisation/state variants (reported in full in `results/e3_auction_auroc.json`), so the best one is exploratory. (3) *Simultaneous, fully observable games only.* We did not implement the sequential / partially observable version (Eq. 3 with private states). (4) *Discretisation and state choice* are researcher degrees of freedom; we report sensitivity where we can. (5) *Replication* is qualitative: the original "game" unit and state abstraction are under-specified. (6) The G-test is anti-conservative at tiny N (FPR 10–12% at 25 rounds); use the permutation test there. (7) The LLM judge in E4 is the same small model as the agents; a stronger judge could do better.

**Dual use.** Knowing what a detector conditions on tells colluders how to evade it. E2 shows that coordination expressed as a fixed function of the auditor's state is invisible to conditional MI, and E3 shows that frozen prices carry no action entropy. We consider this low marginal risk. The evasion strategies are standard in the cartel literature (rotation schemes, focal prices) and are already accessible to any capable agent, while making them explicit helps auditors choose states and combine evidence. We release no attack tooling. All agents are simulated, no real market or person is involved, and the auction data are public research logs.

**AI assistance.** Code, experiments and the report draft were produced with an AI coding assistant (Claude Code), under the author's direction. All numbers in this report are generated by the released scripts (`experiments/tables.py`) from saved result files.

**Pre-existing work.** No code predates the sprint. We use the sprint starter repository only for the released Agrawal et al. auction logs (unchanged). The Modal vLLM server file is adapted from the starter repo's `poseidon_compute.modal_serve`.

## Appendix B – Reproducibility
`uv run pytest` (11 estimator tests) · `experiments/e1_rps_replication.py 400` · `experiments/e2_market_scripted.py 300` · `experiments/e3_double_auction.py` · `experiments/e4_llm_market.py --games 12 --rounds 20` (needs an OpenAI-compatible endpoint; we used `mlx_lm.server` with `mlx-community/Qwen2.5-7B-Instruct-4bit`, temperature 0.7) · `experiments/e4_analyze.py` · `experiments/e4_exploratory.py` · `experiments/figures.py` · `experiments/tables.py`. Seeds are fixed in each script.
