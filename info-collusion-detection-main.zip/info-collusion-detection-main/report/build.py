"""Render report.md -> report.html -> report.pdf (headless Chrome)."""
import subprocess
import sys
from pathlib import Path

import markdown

HERE = Path(__file__).resolve().parent
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

CSS = """
@page { size: A4; margin: 18mm 17mm 18mm 17mm; }
body { font-family: "Times New Roman", Times, serif; font-size: 10.5pt; line-height: 1.38; color: #111; }
h1 { font-size: 16pt; text-align: center; margin: 0 0 6pt; line-height: 1.2; }
h2 { font-size: 12pt; margin: 12pt 0 4pt; }
h3 { font-size: 10.8pt; margin: 9pt 0 3pt; }
p { margin: 0 0 6pt; text-align: justify; }
.authors { text-align: center; font-size: 9.5pt; margin-bottom: 8pt; }
img { width: 100%; margin: 4pt 0 0; }
table { border-collapse: collapse; margin: 4pt auto 8pt; font-size: 8.6pt; }
th, td { border-top: 0.6pt solid #888; border-bottom: 0.6pt solid #888; padding: 2pt 5pt; text-align: center; }
th { background: #f1f0ec; }
code { font-size: 9pt; }
pre { background: #f1f0ec; padding: 5pt 7pt; font-size: 8.6pt; white-space: pre-wrap; margin: 0 0 6pt; }
ul, ol { margin: 0 0 6pt 16pt; padding: 0; }
li { margin-bottom: 2pt; }
em { color: #222; }
hr { page-break-after: always; border: 0; }
"""


def main(src: Path = HERE / "report.md"):
    md = src.read_text()
    body = markdown.markdown(md, extensions=["tables", "sane_lists", "fenced_code"])
    html = f"<!DOCTYPE html><html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{body}</body></html>"
    out, pdf = src.with_suffix(".html"), src.with_suffix(".pdf")
    out.write_text(html)
    subprocess.run([CHROME, "--headless", "--disable-gpu", "--no-pdf-header-footer",
                    f"--print-to-pdf={pdf}", out.as_uri()], check=True, capture_output=True)
    out.unlink()
    print("wrote", pdf)


if __name__ == "__main__":
    main(*[Path(a).resolve() for a in sys.argv[1:2]])
