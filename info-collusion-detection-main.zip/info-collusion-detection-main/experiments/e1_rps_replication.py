"""E1 - positive control: replicate Bonjour et al. (UAI 2022) on scripted iterated RPS.

Three players (A primary colluder, B assistant with collusion probability CP, C random) and the
four-player variant. For each (CP, number of rounds) we run many independent iterations and report the
collusion detection accuracy (CDA: the rule returns exactly the true pair) and the false-positive rate
at CP=0, for (i) the paper's rule (net influence >= alpha=0.05 on plug-in MI) and (ii) our calibrated
rule (G-test of independence, Bonferroni over pairs, plus a positive
net-influence requirement so that exactly one pair is returned).
"""
from __future__ import annotations

import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from infocollusion.estimators import (  # noqa: E402
    bonjour_detect, g_test, influence_matrix, net_influence,
)
from infocollusion.games import rps_assistant  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results"
OUT.mkdir(exist_ok=True)


def calibrated_detect(actions, level=0.05):
    n = actions.shape[1]
    pairs = list(combinations(range(n), 2))
    pvals = {p: g_test(actions[:, p[0]], actions[:, p[1]])[1] for p in pairs}
    big = net_influence(influence_matrix(actions, None, miller_madow=True))
    hits = [p for p in pairs if pvals[p] <= level / len(pairs) and big[p] > 0 and big[p[::-1]] > 0]
    return hits[0] if len(hits) == 1 else None


def main(iters=300, cps=(0.0, 0.1, 0.2, 0.3, 0.4, 0.6, 1.0),
         rounds=(25, 50, 100, 200, 400, 1000), out="e1_rps.json"):
    rng = np.random.default_rng(2026)
    rows = []
    for n_players in (3, 4):
        for cp in cps:
            for T in rounds:
                hit_b = hit_c = 0
                gammas = []
                for _ in range(iters):
                    a = rps_assistant(T, cp, n_players, rng)
                    g = influence_matrix(a, None)
                    big = net_influence(g) / np.log(2)
                    gammas.append(min(big[0, 1], big[1, 0]))
                    db = bonjour_detect(g, alpha=0.05)
                    dc = calibrated_detect(a)
                    if cp == 0:            # any detection is a false positive
                        hit_b += db is not None
                        hit_c += dc is not None
                    else:
                        hit_b += db == (0, 1)
                        hit_c += dc == (0, 1)
                row = dict(n_players=n_players, cp=cp, rounds=T,
                           bonjour_rate=hit_b / iters, calibrated_rate=hit_c / iters,
                           netinf_bits_mean=float(np.mean(gammas)), netinf_bits_sd=float(np.std(gammas)))
                rows.append(row)
                print(row, flush=True)
    (OUT / out).write_text(json.dumps(rows, indent=1))


if __name__ == "__main__":
    main(iters=int(sys.argv[1]) if len(sys.argv) > 1 else 300)
