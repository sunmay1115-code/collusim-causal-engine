"""Print the report's tables (markdown) straight from results/*.json, so no number is hand-copied."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"


def t1_rps():
    rows = json.loads((RES / "e1_rps.json").read_text())
    print("| Players | CP | Rounds | Bonjour rule (α=0.05 bits) | Calibrated test |")
    print("|---|---|---|---|---|")
    keep = {(0.0, 25), (0.0, 50), (0.0, 100), (0.0, 1000), (0.1, 1000), (0.2, 100), (0.2, 1000),
            (0.3, 100), (0.3, 1000)}
    for r in rows:
        if (r["cp"], r["rounds"]) in keep:
            tag = " (FPR)" if r["cp"] == 0 else ""
            print(f"| {r['n_players']} | {r['cp']}{tag} | {r['rounds']} | {r['bonjour_rate']:.2f} | "
                  f"{r['calibrated_rate']:.2f} |")


def t2_market():
    rows = json.loads((RES / "e2_market.json").read_text())
    ms = [("pearson", "Pearson"), ("agreement", "Agreement z"), ("mi_uncond", "MI (no state)"),
          ("cmi", "CMI given state"), ("netinf", "Net infl. given state"), ("perm_z", "Calibrated z")]
    print("| Scenario | Rounds | " + " | ".join(m[1] for m in ms) + " |")
    print("|---|---|" + "---|" * len(ms))
    for r in rows:
        if r["scenario"].startswith("null"):
            continue
        if r["rounds"] not in (20, 50, 200):
            continue
        cells = [f"{r[f'top1_{m}']:.2f} / {r[f'auroc_{m}']:.2f}" for m, _ in ms]
        print(f"| {r['scenario']} | {r['rounds']} | " + " | ".join(cells) + " |")
    print("\nTwin pair ranked first (collude_cp0.5):")
    for r in rows:
        if r["scenario"] == "collude_cp0.5":
            print(r["rounds"], {m: round(r[f"top1twins_{m}"], 2) for m, _ in ms})


def t4_llm():
    p = RES / "e4_games_analysis.json"
    if not p.exists():
        print("(E4 not analysed yet)")
        return
    a = json.loads(p.read_text())
    print("n games:", a["n_games"])
    print("\n| Condition | Pair same-region rate | Other pairs | Pair split 60/30 rate | Pair earnings/round | Other pairs |")
    print("|---|---|---|---|---|---|")
    for c, r in a["positive_control"].items():
        print(f"| {c} | {r['pair_collide']:.2f} | {r['other_collide']:.2f} | {r['pair_split_6030']:.2f} | "
              f"{r['pair_earn']:.1f} | {r['other_earn']:.1f} |")
    names = {"perm_z": "Calibrated MI z (ours)", "lag_z": "Calibrated lagged MI z (ours)",
             "netinf": "Net influence (Bonjour)", "mi": "Plug-in MI", "pearson": "Pearson |r|",
             "agreement": "Agreement-rate z", "avoidance": "Avoidance (game-aware)",
             "judge": "LLM judge (public record)"}
    print("\n| Method | Channel: top-1 | Channel: AUROC | Tacit: top-1 | Tacit: AUROC |")
    print("|---|---|---|---|---|")
    d = a["detection"]
    for m, n in names.items():
        print(f"| {n} | {d['channel'][m]['top1']:.2f} | {d['channel'][m]['auroc_pair_vs_indep']:.2f} | "
              f"{d['tacit'][m]['top1']:.2f} | {d['tacit'][m]['auroc_pair_vs_indep']:.2f} |")
    print("\nBonjour rule:", d["channel"]["bonjour_rule"], d["tacit"]["bonjour_rule"],
          "indep FPR", d["indep_bonjour_false_positive"])


if __name__ == "__main__":
    t1_rps()
    print()
    t2_market()
    print()
    t4_llm()
