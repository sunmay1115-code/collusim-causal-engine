"""E2 - scripted four-firm market-division game: ranking the true pair under a same-policy confound.

Scenarios (agents 0,1 are the candidate pair; agents 2,3 are 'twins' in all but null_indep):
  null_indep : 4 independent softmax firms                         (no collusion, no confound)
  null_twins : 2 independent + 2 twins                            (no collusion, confound present)
  collude    : covert colluders (shared secret coin, prob CP) + 2 twins
  rotate     : ex-ante rotation plan (parity of round, CP=1) + 2 twins; audited with state = values
               only, and with state = values x round parity (the information the plan uses).
Metrics per (scenario, rounds): top-1 accuracy of each pair score (is seats 0-1 ranked most
suspicious of the 6 pairs) and pair-level AUROC (score of seats 0-1 vs the same seats in null_twins).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from infocollusion.baselines import auroc, score_pairs, top_pair  # noqa: E402
from infocollusion.games import market_game  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results"
METHODS = ["pearson", "agreement", "mi_uncond", "netinf_uncond", "cmi", "netinf", "perm_z"]


def top1_share(scores: dict, pair: str) -> float:
    """1/k if `pair` is among the k pairs tied for the highest score, else 0 (fair tie-breaking)."""
    best = max(scores.values())
    tied = [p for p, v in scores.items() if np.isclose(v, best, rtol=0, atol=1e-12)]
    return 1.0 / len(tied) if pair in tied else 0.0


def run(iters=200, rounds=(20, 50, 100, 200), n_perm=100, seed=7):
    rng = np.random.default_rng(seed)
    scen = {
        "null_indep": (["indep"] * 4, 0.0, False),
        "null_twins": (["indep", "indep", "twin", "twin"], 0.0, False),
        "collude_cp0.25": (["colluder", "colluder", "twin", "twin"], 0.25, False),
        "collude_cp0.5": (["colluder", "colluder", "twin", "twin"], 0.5, False),
        "collude_cp1.0": (["colluder", "colluder", "twin", "twin"], 1.0, False),
        "rotate_state=values": (["rotator", "rotator", "twin", "twin"], 1.0, False),
        "rotate_state=values+parity": (["rotator", "rotator", "twin", "twin"], 1.0, True),
    }
    raw = {}
    for name, (roles, cp, parity_state) in scen.items():
        for T in rounds:
            recs = []
            for _ in range(iters):
                a, st, _ = market_game(T, roles, cp=cp, rng=rng)
                s = st * 2 + (np.arange(T) % 2) if parity_state else st
                sc = score_pairs(a, s, n_perm=n_perm, rng=rng)
                recs.append({m: {f"{i}-{j}": v for (i, j), v in sc[m].items()} for m in METHODS})
            raw[(name, T)] = recs
            print(name, T, "done", flush=True)
    summary = []
    for (name, T), recs in raw.items():
        row = {"scenario": name, "rounds": T}
        for m in METHODS:
            row[f"top1_{m}"] = float(np.mean([top1_share(r[m], "0-1") for r in recs]))
            row[f"top1twins_{m}"] = float(np.mean([top1_share(r[m], "2-3") for r in recs]))
            # pair-level: seats 0-1 when colluding vs seats 0-1 when independent (null_twins)
            null = [r[m]["0-1"] for r in raw[("null_twins", T)]]
            row[f"auroc_{m}"] = auroc([r[m]["0-1"] for r in recs], null)
        summary.append(row)
    (OUT / "e2_market.json").write_text(json.dumps(summary, indent=1))
    return summary


if __name__ == "__main__":
    for row in run(iters=int(sys.argv[1]) if len(sys.argv) > 1 else 200):
        print(row["scenario"], row["rounds"],
              {m: (round(row[f"top1_{m}"], 2), round(row[f"auroc_{m}"], 2)) for m in METHODS})
