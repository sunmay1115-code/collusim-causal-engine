"""Figures for the report (static PNG/PDF). One fixed colour per method across every figure;
markers give a second, non-colour cue. Palette: reference categorical slots 1-4 (validated light)."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import NullFormatter  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RES, FIG = ROOT / "results", ROOT / "figures"
FIG.mkdir(exist_ok=True)

INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
STYLE = {  # method -> (label, colour, marker)
    "perm_z":    ("Calibrated MI (ours)", "#2a78d6", "o"),
    "calibrated": ("Calibrated test (ours)", "#2a78d6", "o"),
    "netinf":    ("Net influence (Bonjour)", "#eb6834", "s"),
    "bonjour":   ("Bonjour rule, α=0.05 bits", "#eb6834", "s"),
    "agreement": ("Agreement-rate z", "#1baf7a", "^"),
    "pearson":   ("Pearson |r|", "#eda100", "D"),
}
plt.rcParams.update({
    "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
    "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "figure.facecolor": SURF,
    "axes.facecolor": SURF, "savefig.facecolor": SURF, "legend.frameon": False, "lines.linewidth": 2,
    "lines.markersize": 5,
})


def _line(ax, x, y, key, **kw):
    label, c, m = STYLE[key]
    ax.plot(x, y, color=c, marker=m, label=label, markeredgecolor=SURF, markeredgewidth=0.8, **kw)


def fig_e1():
    rows = [r for r in json.loads((RES / "e1_rps.json").read_text()) if r["n_players"] == 3]
    fig, axes = plt.subplots(1, 4, figsize=(10, 2.6), sharey=True)
    panels = [(0.0, "No collusion (CP=0)\nfalse-positive rate"), (0.1, "CP = 0.1"), (0.2, "CP = 0.2"),
              (0.3, "CP = 0.3")]
    for ax, (cp, title) in zip(axes, panels):
        rs = sorted([r for r in rows if r["cp"] == cp], key=lambda r: r["rounds"])
        x = [r["rounds"] for r in rs]
        _line(ax, x, [r["bonjour_rate"] for r in rs], "bonjour")
        _line(ax, x, [r["calibrated_rate"] for r in rs], "calibrated")
        ax.set_xscale("log")
        ax.set_xticks([25, 100, 400, 1000], ["25", "100", "400", "1000"])
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_title(title, fontsize=9, color=INK)
        ax.set_xlabel("rounds observed")
        if cp == 0.0:
            ax.axhline(0.05, color=INK2, lw=0.8, ls="--")
            ax.text(1000, 0.08, "nominal 5%", ha="right", color=INK2, fontsize=7.5)
    axes[0].set_ylabel("rate (detect true pair)")
    axes[0].set_ylim(-0.02, 1.02)
    axes[-1].legend(loc="lower right", fontsize=7.5)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(FIG / f"fig1_rps_replication.{ext}", dpi=200)


def fig_e2():
    rows = json.loads((RES / "e2_market.json").read_text())
    panels = [("collude_cp0.25", "Covert pair, CP=0.25"), ("collude_cp0.5", "Covert pair, CP=0.5"),
              ("rotate_state=values", "Ex-ante rotation,\nauditor state = values"),
              ("rotate_state=values+parity", "Ex-ante rotation,\nstate = values + parity")]
    fig, axes = plt.subplots(1, 4, figsize=(10, 3.0), sharey=True)
    for ax, (scen, title) in zip(axes, panels):
        rs = sorted([r for r in rows if r["scenario"] == scen], key=lambda r: r["rounds"])
        x = [r["rounds"] for r in rs]
        for m in ("pearson", "agreement", "netinf", "perm_z"):
            _line(ax, x, [r[f"top1_{m}"] for r in rs], m)
        ax.axhline(1 / 6, color=INK2, lw=0.8, ls="--")
        ax.set_xscale("log")
        ax.set_xticks([20, 50, 100, 200], ["20", "50", "100", "200"])
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_title(title, fontsize=9, color=INK)
        ax.set_xlabel("rounds observed")
    axes[0].set_ylabel("P(true pair ranked first)")
    axes[0].set_ylim(-0.02, 1.02)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, fontsize=8)
    fig.tight_layout(rect=(0, 0.09, 1, 1))
    for ext in ("png", "pdf"):
        fig.savefig(FIG / f"fig2_market_scripted.{ext}", dpi=200)


def fig_e3():
    table = json.loads((RES / "e3_auction_auroc.json").read_text())
    setting = "eps=0.25,state=trade,contemp"
    lag = "eps=0.25,state=trade,lagged"
    get = lambda s, c: next(r for r in table if r["setting"] == s and r["comparison"] == c)  # noqa: E731
    items = [("Excess MI vs cross-run surrogates (ours)", "excess", setting),
             ("Excess lagged MI (ours, exploratory)", "excess", lag),
             ("Max net influence (Bonjour)", "max_netinf", setting),
             ("Mean pairwise Pearson r", "pearson", setting),
             ("Price-matching rate", "match_rate", setting),
             ("Ask level (collusion index)", "ask_index", setting),
             ("LLM judge (reads messages)", "judge", setting)]
    fig, ax = plt.subplots(figsize=(6.4, 2.9))
    for k, (comp, colour, mk, lab) in enumerate([
            ("base_vs_comms", "#2a78d6", "o", "Baseline GPT-4.1: chat (10) vs no chat (10)"),
            ("all_comms_vs_none", "#eb6834", "s", "All runs: chat (65) vs no chat (10)")]):
        ys = [len(items) - 1 - i + (0.12 if k == 0 else -0.12) for i in range(len(items))]
        xs = [get(s, comp)[m] for _, m, s in items]
        ax.scatter(xs, ys, color=colour, marker=mk, s=36, label=lab, zorder=3, edgecolor=SURF, linewidth=0.8)
    ax.axvline(0.5, color=INK2, lw=0.8, ls="--")
    ax.set_yticks(range(len(items)), [i[0] for i in items][::-1])
    ax.set_xlim(0, 1.02)
    ax.set_xlabel("AUROC: seller groups with vs without chat")
    ax.legend(loc="lower center", bbox_to_anchor=(0.35, 1.0), ncol=1, fontsize=7.5)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(FIG / f"fig3_double_auction.{ext}", dpi=200)


def fig_e4():
    path = RES / "e4_games_analysis.json"
    if not path.exists():
        return
    det = json.loads(path.read_text())["detection"]
    methods = [("perm_z", "Calibrated MI (ours)"), ("lag_z", "Calibrated lagged MI (ours)"),
               ("netinf", "Net influence (Bonjour)"), ("mi", "Plug-in MI"), ("pearson", "Pearson |r|"),
               ("agreement", "Agreement-rate z"), ("avoidance", "Avoidance (game-aware)"),
               ("judge", "LLM judge (public record)")]
    fig, axes = plt.subplots(1, 2, figsize=(8, 2.9), sharey=True)
    for ax, metric, xl in [(axes[0], "top1", "P(true pair ranked first of 6)"),
                           (axes[1], "auroc_pair_vs_indep", "AUROC: true pair vs pairs in no-collusion games")]:
        for k, (cond, colour, mk, lab) in enumerate([("channel", "#2a78d6", "o", "Private channel"),
                                                     ("tacit", "#eb6834", "s", "Tacit (no channel)")]):
            if cond not in det:
                continue
            ys = [len(methods) - 1 - i + (0.12 if k == 0 else -0.12) for i in range(len(methods))]
            xs = [det[cond][m][metric] for m, _ in methods]
            ax.scatter(xs, ys, color=colour, marker=mk, s=36, label=lab, zorder=3, edgecolor=SURF, linewidth=0.8)
        ax.axvline(1 / 6 if metric == "top1" else 0.5, color=INK2, lw=0.8, ls="--")
        ax.set_xlim(0, 1.02)
        ax.set_xlabel(xl, fontsize=8)
    axes[0].set_yticks(range(len(methods)), [m[1] for m in methods][::-1])
    axes[0].legend(loc="lower right", fontsize=7.5)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(FIG / f"fig4_llm_market.{ext}", dpi=200)


if __name__ == "__main__":
    fig_e1()
    fig_e2()
    fig_e3()
    fig_e4()
    print("figures written to", FIG)
