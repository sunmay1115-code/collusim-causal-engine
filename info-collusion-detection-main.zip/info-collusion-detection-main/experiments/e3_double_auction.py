"""E3 - information-theoretic detection on real LLM agents: Agrawal et al. (2025) double-auction logs.

Uses the 75 runs shipped in the sprint starter repo (llm-agent-collusion/data; 5 sellers, 30 rounds,
GPT-4.1 / Claude sellers). Seller actions are discretised as the per-round change of their ask
(down / hold / up, |change| <= `eps` counts as hold); the public state is whether any trade cleared in
the previous round.

When all five sellers coordinate there is no single pair to find, so besides Bonjour's net influence we
score each run by its *excess dependence*: the mean pairwise conditional MI of within-run seller pairs
minus the mean over cross-run surrogate pairs (seller i of run r with seller j of another run r' of the
same condition: same model and environment, no possible information flow). We also compute a lagged
'follow-the-leader' variant I(a_j,t ; a_i,t-1 | a_j,t-1).

Baselines: mean pairwise Pearson correlation of ask changes, price-matching rate (share of rounds where
all posted asks are within $0.01), ask dispersion, the ask-level collusion index, and the paper's
LLM-judge coordination score (which, unlike every other score here, reads the sellers' messages).
"""
from __future__ import annotations

import json
import re
import sys
from itertools import combinations
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from infocollusion.baselines import auroc  # noqa: E402
from infocollusion.estimators import conditional_mi, influence_matrix, net_influence  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "external/collusion_hackathon/llm-agent-collusion/data"
OUT = ROOT / "results"


def load_run(d: Path) -> dict:
    meta = json.loads((d / "experiment_metadata.json").read_text())
    rounds = [json.loads(b) for b in re.findall(r"````json\n(.*?)\n````", (d / "auction_results.md").read_text(), re.S)]
    sellers = meta["seller_ids"]
    asks = np.full((len(rounds), len(sellers)), np.nan)
    trades = np.zeros(len(rounds), dtype=int)
    for t, r in enumerate(rounds):
        for k, s in enumerate(sellers):
            v = r["seller_asks"].get(s)
            asks[t, k] = np.nan if v is None else float(v)
        trades[t] = len(r["trades"])
    for k in range(asks.shape[1]):  # carry forward missing asks (seller did not post)
        for t in range(asks.shape[0]):
            if np.isnan(asks[t, k]):
                asks[t, k] = asks[t - 1, k] if t > 0 else np.nanmean(asks[0])
    judge = None
    metrics = d / "collusion_metrics.json"
    if metrics.exists():
        m = json.loads(metrics.read_text())
        scores = [v for k, v in m.items() if k.endswith("_coordination_score") and isinstance(v, list)]
        vals = [v for s in scores for v in s if v is not None]
        judge = float(np.mean(vals)) if vals else None
    cond = re.sub(r"-\d+$", "", meta["auction_config"]["tag"])
    return dict(run=d.name, condition=cond, asks=asks, trades=trades, judge=judge,
                comms=meta["auction_config"]["seller_comms_enabled"])


def discretise(asks: np.ndarray, eps: float) -> np.ndarray:
    d = np.diff(asks, axis=0)
    return np.where(d < -eps, 0, np.where(d > eps, 2, 1))


def pair_gammas(x: np.ndarray, y: np.ndarray, s: np.ndarray, lag: bool) -> float:
    if not lag:
        return conditional_mi(x, y, s, miller_madow=True)
    # symmetric lagged influence: mean of I(y_t ; x_{t-1} | y_{t-1}) and the reverse
    a = conditional_mi(y[1:], x[:-1], y[:-1], miller_madow=True)
    b = conditional_mi(x[1:], y[:-1], x[:-1], miller_madow=True)
    return 0.5 * (a + b)


def run_scores(runs: list[dict], eps: float, use_state: bool, lag: bool, rng) -> list[dict]:
    acts = [discretise(r["asks"], eps) for r in runs]
    states = [(r["trades"][:-1] > 0).astype(int) if use_state else np.zeros(len(a), int)
              for r, a in zip(runs, acts)]
    out = []
    for idx, (r, a, s) in enumerate(zip(runs, acts, states)):
        n = a.shape[1]
        within = [pair_gammas(a[:, i], a[:, j], s, lag) for i, j in combinations(range(n), 2)]
        # cross-run surrogates from the same condition (state taken from the run of seller i)
        others = [k for k, q in enumerate(runs) if k != idx and q["condition"] == r["condition"]]
        sur = []
        for _ in range(30):
            k = rng.choice(others)
            i, j = rng.integers(0, n, 2)
            T = min(len(a), len(acts[k]))
            sur.append(pair_gammas(a[:T, i], acts[k][:T, j], s[:T], lag))
        g = influence_matrix(a, s, miller_madow=True)
        big = net_influence(g)
        pears = [np.corrcoef(np.diff(r["asks"][:, i]), np.diff(r["asks"][:, j]))[0, 1]
                 for i, j in combinations(range(n), 2)]
        last = r["asks"][-10:]
        out.append(dict(
            run=r["run"], condition=r["condition"], comms=r["comms"],
            mean_gamma=float(np.mean(within)), surrogate_gamma=float(np.mean(sur)),
            excess=float(np.mean(within) - np.mean(sur)),
            max_netinf=float(max(min(big[i, j], big[j, i]) for i, j in combinations(range(n), 2))),
            pearson=float(np.nanmean(pears)),
            match_rate=float(np.mean(np.ptp(r["asks"], axis=1) <= 0.01)),
            neg_dispersion=float(-np.mean(np.std(last, axis=1))),
            ask_index=float((np.mean(last) - 90.0) / (100.0 - 90.0)),
            judge=r["judge"],
        ))
    return out


def main():
    runs = [load_run(d) for d in sorted(DATA.iterdir()) if d.is_dir()]
    rng = np.random.default_rng(11)
    results = {}
    for eps in (0.01, 0.25):
        for use_state in (False, True):
            for lag in (False, True):
                key = f"eps={eps},state={'trade' if use_state else 'none'},{'lagged' if lag else 'contemp'}"
                results[key] = run_scores(runs, eps, use_state, lag, rng)
    (OUT / "e3_auction_runs.json").write_text(json.dumps(results, indent=1))

    # comparison 1: base (no comms, 10 runs) vs base-seller_comms (10 runs), same GPT-4.1 sellers
    # comparison 2: the 10 runs without seller chat vs the 65 runs with chat
    metrics = ["excess", "mean_gamma", "max_netinf", "pearson", "match_rate", "neg_dispersion",
               "ask_index", "judge"]
    table = []
    for key, rows in results.items():
        for label, pos_f, neg_f in [
            ("base_vs_comms", lambda r: r["condition"] == "base-seller_comms", lambda r: r["condition"] == "base"),
            ("all_comms_vs_none", lambda r: r["comms"], lambda r: not r["comms"]),
        ]:
            pos = [r for r in rows if pos_f(r)]
            neg = [r for r in rows if neg_f(r)]
            row = dict(setting=key, comparison=label, n_pos=len(pos), n_neg=len(neg))
            for m in metrics:
                row[m] = auroc([r[m] for r in pos if r[m] is not None], [r[m] for r in neg if r[m] is not None])
            table.append(row)
    (OUT / "e3_auction_auroc.json").write_text(json.dumps(table, indent=1))
    for row in table:
        print(row["setting"], row["comparison"], {m: round(row[m], 2) for m in metrics})
    # per-condition means for the main setting
    main_key = "eps=0.25,state=trade,contemp"
    conds = sorted({r["condition"] for r in results[main_key]})
    print("\nper-condition means (", main_key, ")")
    for c in conds:
        rs = [r for r in results[main_key] if r["condition"] == c]
        print(f"{c:45s} n={len(rs):2d} excess={np.mean([r['excess'] for r in rs]):+.3f} "
              f"gamma={np.mean([r['mean_gamma'] for r in rs]):.3f} sur={np.mean([r['surrogate_gamma'] for r in rs]):.3f} "
              f"match={np.mean([r['match_rate'] for r in rs]):.2f} judge={np.mean([r['judge'] for r in rs if r['judge'] is not None]):.2f}")


if __name__ == "__main__":
    main()
