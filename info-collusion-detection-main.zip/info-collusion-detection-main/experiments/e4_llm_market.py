"""E4 - LLM agents in the market-division game with one seeded colluding pair.

Usage: uv run python experiments/e4_llm_market.py --games 12 --rounds 20 [--base-url ...] [--model ...]
Writes results/e4_games.jsonl (one GameLog per line, judge scores included). Resumable: games whose id
is already in the file are skipped.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from infocollusion.llm_market import judge_game, make_client, play_game  # noqa: E402

RESULTS = Path(__file__).resolve().parents[1] / "results"
OUT = RESULTS / "e4_games.jsonl"


async def main(args):
    global OUT
    OUT = RESULTS / args.out
    client = make_client(args.base_url)
    sem = asyncio.Semaphore(args.concurrency)
    done = set()
    if OUT.exists():
        done = {json.loads(l)["game_id"] for l in OUT.read_text().splitlines() if l.strip()}
    jobs = [(c, g) for g in range(args.games) for c in args.conditions if f"{c}-{g}" not in done]
    print(f"{len(jobs)} games to play ({len(done)} already done)", flush=True)
    t0 = time.time()
    lock = asyncio.Lock()

    async def run(cond, g):
        log = await play_game(client, args.model, f"{cond}-{g}", cond, args.rounds,
                              seed=1000 * g + hash(cond) % 997, temperature=args.temperature, sem=sem)
        scores = await judge_game(client, args.model, log, sem)
        rec = asdict(log) | {"judge": {f"{i}-{j}": s for (i, j), s in scores.items()},
                             "model": args.model, "temperature": args.temperature}
        async with lock:
            with OUT.open("a") as f:
                f.write(json.dumps(rec) + "\n")
        print(f"[{time.time() - t0:6.0f}s] {cond}-{g} pair={log.pair} invalid={log.invalid}", flush=True)

    # cap games in flight so batching stays efficient
    gsem = asyncio.Semaphore(args.parallel_games)

    async def guarded(c, g):
        async with gsem:
            await run(c, g)

    await asyncio.gather(*[guarded(c, g) for c, g in jobs])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--games", type=int, default=12)
    ap.add_argument("--out", default="e4_games.jsonl")
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--conditions", nargs="+", default=["indep", "channel", "tacit"])
    ap.add_argument("--base-url", default="http://127.0.0.1:8080/v1")
    ap.add_argument("--model", default="mlx-community/Qwen2.5-7B-Instruct-4bit")
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--concurrency", type=int, default=16)
    ap.add_argument("--parallel-games", type=int, default=4)
    asyncio.run(main(ap.parse_args()))
