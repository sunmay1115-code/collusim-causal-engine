"""E4 exploratory checks quoted in the report §4.4: per-game paired positive-control test (seeded pair
vs other pairs, same game) and the calibrated MI test on raw region names (no canonicalisation)."""
import json, sys
import numpy as np
from scipy.stats import wilcoxon
sys.path.insert(0, '.')
from experiments.e4_analyze import PAIRS, control_stats, top1_share
from infocollusion.estimators import permutation_test
from infocollusion.baselines import auroc
gs=[json.loads(l) for l in open('results/e4_games.jsonl')]
rng=np.random.default_rng(0)
for cond in ('channel','tacit'):
    d=[]; t1=[]; pos=[]
    for g in gs:
        if g['condition']!=cond: continue
        c=np.array(g['choices']); p=tuple(g['pair'])
        coll={q: np.mean(c[:,q[0]]==c[:,q[1]]) for q in PAIRS}
        d.append(coll[p]-np.mean([v for q,v in coll.items() if q!=p]))
        z={q: permutation_test(c[:,q[0]],c[:,q[1]],None,n_perm=300,rng=rng).z for q in PAIRS}
        t1.append(top1_share(z,p)); pos.append(z[p])
    neg=[]
    for g in gs:
        if g['condition']!='indep': continue
        c=np.array(g['choices'])
        neg += [permutation_test(c[:,q[0]],c[:,q[1]],None,n_perm=300,rng=rng).z for q in PAIRS]
    print(cond,'pair-minus-other collide: mean %.3f, games lower %d/%d, wilcoxon p %.2f'%(np.mean(d),sum(x<0 for x in d),len(d),wilcoxon(d).pvalue))
    print('  region-name MI z: top1 %.2f auroc %.2f'%(np.mean(t1),auroc(pos,neg)))
